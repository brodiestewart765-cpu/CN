import clsx from "clsx";

type Tone = "neutral" | "info" | "success" | "warning" | "danger" | "violet";

const TONES: Record<Tone, string> = {
  neutral: "bg-surface text-ink-600 ring-1 ring-inset ring-line",
  info: "bg-info-50 text-info-700 ring-1 ring-inset ring-info-100",
  success: "bg-success-50 text-success-700 ring-1 ring-inset ring-success-100",
  warning: "bg-warning-50 text-warning-700 ring-1 ring-inset ring-warning-100",
  danger: "bg-danger-50 text-danger-600 ring-1 ring-inset ring-danger-100",
  violet: "bg-primary-50 text-primary-700 ring-1 ring-inset ring-primary-100",
};

// Central mapping from any status string -> tone. One source of truth.
const STATUS_TONE: Record<string, Tone> = {
  New: "info",
  Contacted: "success",
  "In Progress": "warning",
  Qualified: "violet",
  Lost: "danger",
  Scheduled: "info",
  "On the way": "violet",
  Completed: "success",
  Cancelled: "danger",
  Active: "success",
  Inactive: "neutral",
  "On Leave": "warning",
  Draft: "neutral",
  Sent: "info",
  Accepted: "success",
  Declined: "danger",
  Planned: "info",
  High: "danger",
  Medium: "warning",
  Low: "neutral",
};

export function StatusBadge({
  status,
  tone,
}: {
  status: string;
  tone?: Tone;
}) {
  const t = tone ?? STATUS_TONE[status] ?? "neutral";
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-2xs font-medium",
        TONES[t]
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />
      {status}
    </span>
  );
}
