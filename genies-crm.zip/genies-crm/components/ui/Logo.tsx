import Link from "next/link";
import { Icon } from "./Icon";

export function Logo({ href = "/" }: { href?: string }) {
  return (
    <Link href={href} className="flex items-center gap-2.5">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary-500 to-primary-700 shadow-[0_2px_6px_rgba(93,63,214,0.35)]">
        <Icon name="Sparkles" size={17} className="text-white" strokeWidth={2.4} />
      </span>
      <span className="text-[15px] font-bold tracking-tight text-ink-900">
        GENIE&rsquo;S<span className="text-primary-600"> CRM</span>
      </span>
    </Link>
  );
}
