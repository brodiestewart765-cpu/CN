import clsx from "clsx";

const PALETTE = [
  "bg-primary-100 text-primary-700",
  "bg-info-50 text-info-700",
  "bg-success-50 text-success-700",
  "bg-warning-50 text-warning-700",
  "bg-danger-50 text-danger-600",
];

function initials(name: string) {
  const parts = name.trim().split(/\s+/);
  return (parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "");
}

export function Avatar({
  name,
  size = 32,
  className,
}: {
  name: string;
  size?: number;
  className?: string;
}) {
  const idx =
    name.split("").reduce((a, c) => a + c.charCodeAt(0), 0) % PALETTE.length;
  return (
    <span
      className={clsx(
        "inline-flex items-center justify-center rounded-full font-semibold shrink-0",
        PALETTE[idx],
        className
      )}
      style={{ width: size, height: size, fontSize: size * 0.36 }}
    >
      {initials(name).toUpperCase()}
    </span>
  );
}
