export function PageHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
      <div>
        <h1 className="page-title">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-ink-500">{subtitle}</p>}
      </div>
      {action && <div className="flex items-center gap-2">{action}</div>}
    </div>
  );
}

export function Pagination({
  from,
  to,
  total,
  noun = "records",
}: {
  from: number;
  to: number;
  total: number;
  noun?: string;
}) {
  const pages = [1, 2, 3];
  return (
    <>
      <span>
        Showing {from}–{to} of {total} {noun}
      </span>
      <div className="flex items-center gap-1">
        <button className="flex h-7 w-7 items-center justify-center rounded-md border border-line text-ink-400 hover:bg-surface">
          ‹
        </button>
        {pages.map((p) => (
          <button
            key={p}
            className={
              p === 1
                ? "flex h-7 w-7 items-center justify-center rounded-md bg-primary-600 text-xs font-medium text-white"
                : "flex h-7 w-7 items-center justify-center rounded-md border border-line text-xs text-ink-600 hover:bg-surface"
            }
          >
            {p}
          </button>
        ))}
        <button className="flex h-7 w-7 items-center justify-center rounded-md border border-line text-ink-400 hover:bg-surface">
          ›
        </button>
      </div>
    </>
  );
}
