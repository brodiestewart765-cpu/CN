import clsx from "clsx";
import { Icon } from "./Icon";

export interface Column<T> {
  key: string;
  header: string;
  render?: (row: T) => React.ReactNode;
  align?: "left" | "right" | "center";
  className?: string;
  headerClassName?: string;
}

export function DataTable<T extends Record<string, any>>({
  columns,
  rows,
  getKey,
  toolbar,
  footer,
  rowAction = true,
  emptyLabel = "No records found",
}: {
  columns: Column<T>[];
  rows: T[];
  getKey: (row: T) => string;
  toolbar?: React.ReactNode;
  footer?: React.ReactNode;
  rowAction?: boolean;
  emptyLabel?: string;
}) {
  const alignCls = (a?: "left" | "right" | "center") =>
    a === "right" ? "text-right" : a === "center" ? "text-center" : "text-left";

  return (
    <div className="card overflow-hidden">
      {toolbar && (
        <div className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-3">
          {toolbar}
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b border-line bg-surface-sunken">
              {columns.map((c) => (
                <th
                  key={c.key}
                  className={clsx(
                    "whitespace-nowrap px-4 py-2.5 text-2xs font-semibold uppercase tracking-wide text-ink-400",
                    alignCls(c.align),
                    c.headerClassName
                  )}
                >
                  {c.header}
                </th>
              ))}
              {rowAction && <th className="w-10 px-4 py-2.5" />}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td
                  colSpan={columns.length + (rowAction ? 1 : 0)}
                  className="px-4 py-12 text-center text-sm text-ink-400"
                >
                  {emptyLabel}
                </td>
              </tr>
            )}
            {rows.map((row) => (
              <tr
                key={getKey(row)}
                className="group border-b border-line-soft transition-colors last:border-0 hover:bg-surface-sunken"
              >
                {columns.map((c) => (
                  <td
                    key={c.key}
                    className={clsx(
                      "whitespace-nowrap px-4 py-3 text-ink-700",
                      alignCls(c.align),
                      c.className
                    )}
                  >
                    {c.render ? c.render(row) : (row[c.key] as React.ReactNode)}
                  </td>
                ))}
                {rowAction && (
                  <td className="px-4 py-3 text-right">
                    <button className="rounded-md p-1 text-ink-400 opacity-0 transition-opacity hover:bg-surface hover:text-ink-700 group-hover:opacity-100">
                      <Icon name="MoreHorizontal" size={16} />
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {footer && (
        <div className="flex items-center justify-between border-t border-line px-4 py-3 text-xs text-ink-500">
          {footer}
        </div>
      )}
    </div>
  );
}
