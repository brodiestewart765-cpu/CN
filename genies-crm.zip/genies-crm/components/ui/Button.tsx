import clsx from "clsx";
import { Icon } from "./Icon";

type Variant = "primary" | "secondary" | "ghost" | "danger";
type Size = "sm" | "md";

export function Button({
  children,
  variant = "primary",
  size = "md",
  icon,
  iconRight,
  className,
  ...props
}: {
  children?: React.ReactNode;
  variant?: Variant;
  size?: Size;
  icon?: string;
  iconRight?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const base =
    "inline-flex items-center justify-center gap-1.5 font-medium rounded-lg transition-colors whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-200 disabled:opacity-50";
  const sizes: Record<Size, string> = {
    sm: "h-8 px-3 text-xs",
    md: "h-9 px-3.5 text-sm",
  };
  const variants: Record<Variant, string> = {
    primary:
      "bg-primary-600 text-white hover:bg-primary-700 shadow-[0_1px_2px_rgba(16,24,40,0.10)]",
    secondary:
      "bg-white text-ink-700 border border-line hover:bg-surface hover:text-ink-900",
    ghost: "text-ink-600 hover:bg-surface hover:text-ink-900",
    danger: "bg-danger-600 text-white hover:bg-danger-500",
  };
  return (
    <button
      className={clsx(base, sizes[size], variants[variant], className)}
      {...props}
    >
      {icon && <Icon name={icon} size={size === "sm" ? 14 : 16} />}
      {children}
      {iconRight && <Icon name={iconRight} size={size === "sm" ? 14 : 16} />}
    </button>
  );
}
