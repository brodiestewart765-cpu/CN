import clsx from "clsx";
import { Icon } from "./Icon";

type IconTone = "violet" | "green" | "blue" | "amber" | "rose";

const ICON_TONES: Record<IconTone, string> = {
  violet: "bg-primary-50 text-primary-600",
  green: "bg-success-50 text-success-600",
  blue: "bg-info-50 text-info-600",
  amber: "bg-warning-50 text-warning-600",
  rose: "bg-danger-50 text-danger-500",
};

export function KpiCard({
  label,
  value,
  icon,
  iconTone = "violet",
  delta,
  deltaDir = "up",
  sublabel,
}: {
  label: string;
  value: string;
  icon?: string;
  iconTone?: IconTone;
  delta?: string;
  deltaDir?: "up" | "down";
  sublabel?: string;
}) {
  return (
    <div className="card p-4">
      <div className="flex items-start gap-3">
        {icon && (
          <span
            className={clsx(
              "flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
              ICON_TONES[iconTone]
            )}
          >
            <Icon name={icon} size={18} />
          </span>
        )}
        <div className="min-w-0">
          <p className="kpi-label truncate">{label}</p>
          <p className="kpi-value mt-1">{value}</p>
          <div className="mt-1 flex items-center gap-1.5">
            {delta && (
              <span
                className={clsx(
                  "inline-flex items-center gap-0.5 text-xs font-semibold",
                  deltaDir === "up" ? "text-success-600" : "text-danger-500"
                )}
              >
                <Icon
                  name={deltaDir === "up" ? "TrendingUp" : "TrendingDown"}
                  size={13}
                />
                {delta}
              </span>
            )}
            {sublabel && (
              <span className="text-xs text-ink-400">{sublabel}</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
