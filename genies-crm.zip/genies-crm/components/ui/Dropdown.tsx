"use client";

import { useEffect, useRef, useState } from "react";
import clsx from "clsx";
import { Icon } from "./Icon";

export interface DropdownOption {
  value: string;
  label: string;
  sublabel?: string;
  icon?: string;
}

export function Dropdown({
  options,
  value,
  onChange,
  leadingIcon,
  className,
  menuClassName,
  align = "left",
}: {
  options: DropdownOption[];
  value: string;
  onChange: (value: string) => void;
  leadingIcon?: string;
  className?: string;
  menuClassName?: string;
  align?: "left" | "right";
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const selected = options.find((o) => o.value === value) ?? options[0];

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className={clsx("relative", className)} ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="inline-flex h-9 w-full items-center gap-2 rounded-lg border border-line bg-white px-3 text-sm font-medium text-ink-700 transition-colors hover:bg-surface"
      >
        {leadingIcon && (
          <Icon name={leadingIcon} size={16} className="text-ink-400" />
        )}
        <span className="truncate text-ink-800">{selected?.label}</span>
        <Icon
          name="ChevronDown"
          size={16}
          className={clsx("ml-auto text-ink-400 transition-transform", open && "rotate-180")}
        />
      </button>

      {open && (
        <div
          className={clsx(
            "absolute z-50 mt-1.5 min-w-full overflow-hidden rounded-xl border border-line bg-white p-1 shadow-pop",
            align === "right" ? "right-0" : "left-0",
            menuClassName
          )}
        >
          {options.map((o) => (
            <button
              key={o.value}
              onClick={() => {
                onChange(o.value);
                setOpen(false);
              }}
              className={clsx(
                "flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm transition-colors",
                o.value === value
                  ? "bg-primary-50 text-primary-700"
                  : "text-ink-700 hover:bg-surface"
              )}
            >
              {o.icon && <Icon name={o.icon} size={16} className="text-ink-400" />}
              <span className="flex-1">
                <span className="block font-medium leading-tight">{o.label}</span>
                {o.sublabel && (
                  <span className="block text-2xs text-ink-400">{o.sublabel}</span>
                )}
              </span>
              {o.value === value && (
                <Icon name="CheckCircle2" size={15} className="text-primary-600" />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
