"use client";

import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const GREEN = "#12B76A";
const GREEN_LIGHT = "#6CE9A6";

export function RevenueBarChart({
  data,
}: {
  data: { label: string; value: number }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} margin={{ top: 8, right: 4, left: -6, bottom: 0 }}>
        <defs>
          <linearGradient id="barGreen" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={GREEN_LIGHT} />
            <stop offset="100%" stopColor={GREEN} />
          </linearGradient>
        </defs>
        <XAxis
          dataKey="label"
          tickLine={false}
          axisLine={false}
          tick={{ fill: "#98A2B3", fontSize: 11 }}
          interval={0}
        />
        <YAxis
          tickLine={false}
          axisLine={false}
          tick={{ fill: "#98A2B3", fontSize: 11 }}
          width={52}
          tickFormatter={(v) => `$${Math.round(v / 1000)}k`}
        />
        <Tooltip
          cursor={{ fill: "rgba(18,183,106,0.06)" }}
          contentStyle={{
            borderRadius: 10,
            border: "1px solid #EAECF0",
            boxShadow: "0 8px 24px rgba(16,24,40,0.10)",
            fontSize: 12,
          }}
          formatter={(v: number) => [`$${v.toLocaleString()}`, "Revenue"]}
        />
        <Bar dataKey="value" fill="url(#barGreen)" radius={[4, 4, 0, 0]} barSize={16} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function BusinessDonut({
  data,
}: {
  data: { name: string; value: number; color: string }[];
}) {
  const total = data.reduce((a, d) => a + d.value, 0);
  return (
    <div className="flex items-center gap-6">
      <div className="relative h-[168px] w-[168px] shrink-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              innerRadius={54}
              outerRadius={80}
              paddingAngle={2}
              stroke="none"
            >
              {data.map((d, i) => (
                <Cell key={i} fill={d.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                borderRadius: 10,
                border: "1px solid #EAECF0",
                fontSize: 12,
              }}
              formatter={(v: number) => `$${v.toLocaleString()}`}
            />
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xs text-ink-400">Total</span>
          <span className="text-lg font-semibold text-ink-900">
            ${(total / 1000).toFixed(1)}k
          </span>
        </div>
      </div>
      <div className="space-y-3">
        {data.map((d) => (
          <div key={d.name} className="flex items-center gap-2.5">
            <span
              className="h-2.5 w-2.5 rounded-full"
              style={{ backgroundColor: d.color }}
            />
            <div>
              <p className="text-sm font-medium text-ink-800">{d.name}</p>
              <p className="text-xs text-ink-500">
                ${d.value.toLocaleString()} ·{" "}
                {Math.round((d.value / total) * 100)}%
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
