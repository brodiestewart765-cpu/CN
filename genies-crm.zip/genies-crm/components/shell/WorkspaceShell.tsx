"use client";

import { useState } from "react";
import { BusinessId } from "@/lib/types";
import { BUSINESSES } from "@/lib/config";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";

export function WorkspaceShell({
  businessId,
  activeSlug,
  children,
}: {
  businessId: BusinessId;
  activeSlug: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const business = BUSINESSES[businessId];

  return (
    <div className="min-h-screen bg-surface">
      <Sidebar
        items={business.nav}
        basePath={`/w/${businessId}`}
        activeSlug={activeSlug}
        logoHref="/"
        footerLabel={business.name}
        mobileOpen={open}
        onClose={() => setOpen(false)}
      />
      <div className="lg:pl-sidebar">
        <Header scope={businessId} onMenuClick={() => setOpen(true)} />
        <main className="mx-auto max-w-[1400px] px-4 py-6 lg:px-8 lg:py-7">
          {children}
        </main>
      </div>
    </div>
  );
}
