"use client";

import { useState } from "react";
import { MASTER_NAV } from "@/lib/config";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";

export function MasterShell({
  activeSlug,
  scope = "all",
  children,
}: {
  activeSlug: string;
  scope?: "all";
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-surface">
      <Sidebar
        items={MASTER_NAV}
        basePath=""
        activeSlug={activeSlug}
        logoHref="/"
        footerLabel="Owner Workspace"
        mobileOpen={open}
        onClose={() => setOpen(false)}
      />
      <div className="lg:pl-sidebar">
        <Header scope={scope} onMenuClick={() => setOpen(true)} />
        <main className="mx-auto max-w-[1400px] px-4 py-6 lg:px-8 lg:py-7">
          {children}
        </main>
      </div>
    </div>
  );
}
