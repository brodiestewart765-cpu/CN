"use client";

import { useRouter } from "next/navigation";
import { BusinessId } from "@/lib/types";
import { BUSINESSES, locationsFor } from "@/lib/config";
import { useApp } from "@/lib/app-context";
import { Dropdown, DropdownOption } from "../ui/Dropdown";
import { Icon } from "../ui/Icon";
import { Avatar } from "../ui/Avatar";

const BUSINESS_OPTIONS: DropdownOption[] = [
  { value: "all", label: "All Businesses", icon: "Grip" },
  { value: "move", label: "Move Management", icon: "Truck" },
  { value: "window", label: "Window Cleaning", icon: "SquareStack" },
];

export function Header({
  scope,
  onMenuClick,
}: {
  // "all" => master/owner scope (no location selector). Otherwise a business.
  scope: BusinessId | "all";
  onMenuClick?: () => void;
}) {
  const router = useRouter();
  const { user, locationByBusiness, setLocation } = useApp();

  function onBusinessChange(value: string) {
    if (value === "all") router.push("/owner-overview");
    else router.push(`/w/${value}/dashboard`);
  }

  const business = scope === "all" ? undefined : BUSINESSES[scope];
  const locationOptions: DropdownOption[] = business
    ? [
        { value: "all", label: "All Locations", icon: "MapPin" },
        ...locationsFor(business.id).map((l) => ({
          value: l.id,
          label: l.name,
          sublabel: l.city,
          icon: "MapPin",
        })),
      ]
    : [];

  return (
    <header className="sticky top-0 z-30 flex h-header items-center gap-3 border-b border-line bg-white/95 px-4 backdrop-blur lg:px-6">
      <button
        onClick={onMenuClick}
        className="flex h-9 w-9 items-center justify-center rounded-lg text-ink-500 hover:bg-surface lg:hidden"
      >
        <Icon name="Menu" size={20} />
      </button>

      <div className="flex items-center gap-2.5">
        <Dropdown
          options={BUSINESS_OPTIONS}
          value={scope}
          onChange={onBusinessChange}
          className="w-[190px]"
        />
        {business && (
          <Dropdown
            options={locationOptions}
            value={locationByBusiness[business.id]}
            onChange={(v) => setLocation(business.id, v)}
            leadingIcon="MapPin"
            className="hidden w-[170px] sm:block"
          />
        )}
      </div>

      {/* Search */}
      <div className="ml-1 hidden max-w-md flex-1 items-center md:flex">
        <div className="flex h-9 w-full items-center gap-2 rounded-lg border border-line bg-surface px-3 text-sm text-ink-400 transition-colors focus-within:border-primary-300 focus-within:bg-white">
          <Icon name="Search" size={16} />
          <input
            placeholder="Search anything…"
            className="w-full bg-transparent text-ink-800 placeholder:text-ink-400 focus:outline-none"
          />
          <kbd className="hidden rounded border border-line bg-white px-1.5 text-2xs text-ink-400 lg:block">
            ⌘K
          </kbd>
        </div>
      </div>

      <div className="ml-auto flex items-center gap-1">
        <HeaderIcon icon="Search" className="md:hidden" />
        <HeaderIcon icon="Bell" badge />
        <HeaderIcon icon="MessageCircle" badgeCount={3} />
        <HeaderIcon icon="Settings" className="hidden sm:flex" />
        <div className="mx-1 hidden h-6 w-px bg-line sm:block" />
        <button className="flex items-center gap-2 rounded-lg py-1 pl-1 pr-2 hover:bg-surface">
          <Avatar name={user.name} size={32} />
          <span className="hidden text-left leading-tight lg:block">
            <span className="block text-sm font-semibold text-ink-800">
              {user.name.split(" ")[0]}
            </span>
            <span className="block text-2xs text-ink-400 capitalize">
              {user.role}
            </span>
          </span>
          <Icon
            name="ChevronDown"
            size={15}
            className="hidden text-ink-400 lg:block"
          />
        </button>
      </div>
    </header>
  );
}

function HeaderIcon({
  icon,
  badge,
  badgeCount,
  className,
}: {
  icon: string;
  badge?: boolean;
  badgeCount?: number;
  className?: string;
}) {
  return (
    <button
      className={`relative flex h-9 w-9 items-center justify-center rounded-lg text-ink-500 hover:bg-surface hover:text-ink-700 ${className ?? ""}`}
    >
      <Icon name={icon} size={19} strokeWidth={1.9} />
      {badge && (
        <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-danger-500 ring-2 ring-white" />
      )}
      {badgeCount && (
        <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger-500 px-1 text-[9px] font-semibold text-white ring-2 ring-white">
          {badgeCount}
        </span>
      )}
    </button>
  );
}
