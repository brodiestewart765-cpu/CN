"use client";

import Link from "next/link";
import clsx from "clsx";
import { Logo } from "../ui/Logo";
import { Icon } from "../ui/Icon";

interface SidebarItem {
  slug: string;
  label: string;
  icon: string;
  href?: string;
}

export function Sidebar({
  items,
  basePath,
  activeSlug,
  logoHref = "/",
  footerLabel,
  mobileOpen = false,
  onClose,
}: {
  items: SidebarItem[];
  basePath: string; // e.g. "/w/move" or "" for master
  activeSlug: string;
  logoHref?: string;
  footerLabel?: string;
  mobileOpen?: boolean;
  onClose?: () => void;
}) {
  return (
    <>
      {/* Mobile overlay */}
      <div
        className={clsx(
          "fixed inset-0 z-40 bg-ink-900/30 backdrop-blur-sm transition-opacity lg:hidden",
          mobileOpen ? "opacity-100" : "pointer-events-none opacity-0"
        )}
        onClick={onClose}
      />
      <aside
        className={clsx(
          "fixed inset-y-0 left-0 z-50 flex w-sidebar flex-col border-r border-line bg-white transition-transform lg:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex h-header shrink-0 items-center px-5">
          <Logo href={logoHref} />
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-3">
          {items.map((item) => {
            const href =
              item.href ??
              (basePath ? `${basePath}/${item.slug}` : `/${item.slug}`);
            const active = item.slug === activeSlug;
            return (
              <Link
                key={item.slug || "home"}
                href={href || "/"}
                onClick={onClose}
                className={clsx("nav-link", active && "nav-link-active")}
              >
                <Icon
                  name={item.icon}
                  size={18}
                  strokeWidth={active ? 2.2 : 1.9}
                  className={active ? "text-primary-600" : "text-ink-400"}
                />
                <span className="truncate">{item.label}</span>
              </Link>
            );
          })}
        </nav>
        {footerLabel && (
          <div className="shrink-0 border-t border-line px-4 py-3">
            <div className="flex items-center gap-2.5 rounded-lg px-1.5 py-1.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface text-ink-500">
                <Icon name="Circle" size={16} />
              </span>
              <div className="min-w-0">
                <p className="truncate text-xs font-semibold text-ink-800">
                  {footerLabel}
                </p>
                <p className="truncate text-2xs text-ink-400">Genie&rsquo;s CRM</p>
              </div>
            </div>
          </div>
        )}
      </aside>
    </>
  );
}
