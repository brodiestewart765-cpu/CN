"use client";

import { BusinessId } from "@/lib/types";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { RevenueBarChart } from "@/components/charts/Charts";

const REPORTS = [
  { icon: "CircleDollarSign", tone: "bg-success-50 text-success-600", title: "Revenue Report", desc: "Income by period & location" },
  { icon: "Truck", tone: "bg-info-50 text-info-600", title: "Jobs Report", desc: "Completed & scheduled work" },
  { icon: "Users", tone: "bg-primary-50 text-primary-600", title: "Customer Report", desc: "Acquisition & retention" },
  { icon: "UserPlus", tone: "bg-warning-50 text-warning-600", title: "Leads Report", desc: "Sources & conversion" },
  { icon: "Contact", tone: "bg-info-50 text-info-600", title: "Employee Report", desc: "Productivity & hours" },
  { icon: "Star", tone: "bg-warning-50 text-warning-600", title: "Reviews Report", desc: "Ratings over time" },
];

const SERIES = [
  { label: "Jan", value: 32000 }, { label: "Feb", value: 41000 },
  { label: "Mar", value: 38000 }, { label: "Apr", value: 52000 },
  { label: "May", value: 61000 }, { label: "Jun", value: 57000 },
];

export function Reports({ businessId }: { businessId: BusinessId }) {
  return (
    <div>
      <PageHeader
        title="Reports"
        subtitle="Generate and export performance reports"
        action={<Button variant="secondary" icon="Download">Export</Button>}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {REPORTS.map((r) => (
          <button key={r.title} className="card p-5 text-left transition-shadow hover:shadow-pop">
            <span className={`flex h-11 w-11 items-center justify-center rounded-xl ${r.tone}`}>
              <Icon name={r.icon} size={20} />
            </span>
            <p className="mt-3 text-sm font-semibold text-ink-900">{r.title}</p>
            <p className="mt-0.5 text-xs text-ink-500">{r.desc}</p>
            <span className="mt-3 inline-flex items-center gap-1 text-xs font-medium text-primary-600">
              Run report <Icon name="ArrowRight" size={13} />
            </span>
          </button>
        ))}
      </div>

      <Card className="mt-5">
        <CardHeader title="Revenue Trend" subtitle="Last 6 months" />
        <RevenueBarChart data={SERIES} />
      </Card>
    </div>
  );
}
