"use client";

import { useState } from "react";
import { BusinessId } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { useScoped } from "./scoped";
import { CALENDAR_EVENTS } from "@/lib/data";
import clsx from "clsx";

const DAYS = ["Mon 27", "Tue 28", "Wed 29", "Thu 30", "Fri 31"];
const TIMES = ["8 AM", "9 AM", "10 AM", "11 AM", "12 PM", "1 PM"];

const EVENT_COLORS: Record<string, string> = {
  green: "bg-success-50 border-success-500/40 text-success-700",
  amber: "bg-warning-50 border-warning-500/40 text-warning-700",
  violet: "bg-primary-50 border-primary-500/40 text-primary-700",
  blue: "bg-info-50 border-info-500/40 text-info-700",
};

export function Calendar({ businessId }: { businessId: BusinessId }) {
  const [view, setView] = useState("week");
  const events = useScoped(CALENDAR_EVENTS, businessId);

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h1 className="page-title">Calendar</h1>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="secondary" size="sm">Today</Button>
          <div className="flex items-center gap-1">
            <button className="flex h-8 w-8 items-center justify-center rounded-lg border border-line text-ink-500 hover:bg-surface">
              <Icon name="ChevronLeft" size={16} />
            </button>
            <button className="flex h-8 w-8 items-center justify-center rounded-lg border border-line text-ink-500 hover:bg-surface">
              <Icon name="ChevronRight" size={16} />
            </button>
          </div>
          <span className="px-1 text-sm font-medium text-ink-800">May 27 – May 31, 2025</span>
          <div className="ml-1 flex items-center rounded-lg border border-line bg-white p-0.5">
            {["day", "week", "month"].map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={clsx(
                  "rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors",
                  view === v ? "bg-primary-50 text-primary-700" : "text-ink-500 hover:text-ink-800"
                )}
              >
                {v}
              </button>
            ))}
          </div>
        </div>
      </div>

      <Card padded={false} className="overflow-hidden">
        {/* Day header */}
        <div className="grid border-b border-line" style={{ gridTemplateColumns: "64px repeat(5, 1fr)" }}>
          <div className="border-r border-line-soft" />
          {DAYS.map((d) => (
            <div key={d} className="border-r border-line-soft px-3 py-2.5 text-center last:border-0">
              <p className="text-xs font-semibold text-ink-700">{d.split(" ")[0]}</p>
              <p className="text-2xs text-ink-400">{d.split(" ")[1]}</p>
            </div>
          ))}
        </div>
        {/* Grid body */}
        <div
          className="relative grid"
          style={{ gridTemplateColumns: "64px repeat(5, 1fr)", gridTemplateRows: `repeat(${TIMES.length}, 64px)` }}
        >
          {/* time labels + cell backgrounds */}
          {TIMES.map((t, ri) => (
            <div key={t} className="col-start-1 border-r border-t border-line-soft px-2 py-1 text-2xs text-ink-400" style={{ gridRow: ri + 1 }}>
              {t}
            </div>
          ))}
          {TIMES.map((_, ri) =>
            DAYS.map((__, ci) => (
              <div
                key={`${ri}-${ci}`}
                className="border-r border-t border-line-soft last:border-r-0"
                style={{ gridColumn: ci + 2, gridRow: ri + 1 }}
              />
            ))
          )}
          {/* events */}
          {events.map((e) => (
            <div
              key={e.id}
              className={clsx("m-1 overflow-hidden rounded-lg border px-2 py-1.5", EVENT_COLORS[e.color])}
              style={{ gridColumn: e.day + 2, gridRow: `${e.start + 1} / span ${e.span}` }}
            >
              <p className="text-xs font-semibold leading-tight">{e.title}</p>
              <p className="mt-0.5 truncate text-2xs opacity-80">{e.subtitle}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
