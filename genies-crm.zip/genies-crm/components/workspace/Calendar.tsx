"use client";

import { useState } from "react";
import { BusinessId } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { useScoped } from "./scoped";
import { CALENDAR_EVENTS } from "@/lib/data";
import clsx from "clsx";

const DAYS = ["Mon 27", "Tue 28", "Wed 29", "Thu 30", "Fri 31"];
const TIMES = ["8 AM", "9 AM", "10 AM", "11 AM", "12 PM", "1 PM"];

const EVENT_COLORS: Record<string, string> = {
  green: "bg-success-50 border-success-500/40 text-success-700",
  amber: "bg-warning-50 border-warning-500/40 text-warning-700",
  violet: "bg-primary-50 border-primary-500/40 text-primary-700",
  blue: "bg-info-50 border-info-500/40 text-info-700",
};
const DOT: Record<string, string> = {
  green: "bg-success-500", amber: "bg-warning-500", violet: "bg-primary-500", blue: "bg-info-500",
};

export function Calendar({ businessId }: { businessId: BusinessId }) {
  const [view, setView] = useState<"day" | "week" | "month">("week");
  const [dayIdx, setDayIdx] = useState(0); // which weekday for Day view (0-4)
  const events = useScoped(CALENDAR_EVENTS, businessId);

  const label =
    view === "day" ? DAYS[dayIdx] + ", 2025"
      : view === "month" ? "May 2025"
      : "May 27 – May 31, 2025";

  function shift(dir: number) {
    if (view === "day") setDayIdx((d) => Math.min(4, Math.max(0, d + dir)));
  }

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h1 className="page-title">Calendar</h1>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="secondary" size="sm" onClick={() => { setView("day"); setDayIdx(0); }}>Today</Button>
          <div className="flex items-center gap-1">
            <button onClick={() => shift(-1)} className="flex h-8 w-8 items-center justify-center rounded-lg border border-line text-ink-500 hover:bg-surface">
              <Icon name="ChevronLeft" size={16} />
            </button>
            <button onClick={() => shift(1)} className="flex h-8 w-8 items-center justify-center rounded-lg border border-line text-ink-500 hover:bg-surface">
              <Icon name="ChevronRight" size={16} />
            </button>
          </div>
          <span className="px-1 text-sm font-medium text-ink-800">{label}</span>
          <div className="ml-1 flex items-center rounded-lg border border-line bg-white p-0.5">
            {(["day", "week", "month"] as const).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={clsx(
                  "rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors",
                  view === v ? "bg-primary-50 text-primary-700" : "text-ink-500 hover:text-ink-800"
                )}
              >
                {v}
              </button>
            ))}
          </div>
        </div>
      </div>

      {view === "week" && <WeekView events={events} />}
      {view === "day" && <DayView events={events.filter((e) => e.day === dayIdx)} dayLabel={DAYS[dayIdx]} />}
      {view === "month" && <MonthView events={events} />}
    </div>
  );
}

function WeekView({ events }: { events: typeof CALENDAR_EVENTS }) {
  return (
    <Card padded={false} className="overflow-hidden">
      <div className="grid border-b border-line" style={{ gridTemplateColumns: "64px repeat(5, 1fr)" }}>
        <div className="border-r border-line-soft" />
        {DAYS.map((d) => (
          <div key={d} className="border-r border-line-soft px-3 py-2.5 text-center last:border-0">
            <p className="text-xs font-semibold text-ink-700">{d.split(" ")[0]}</p>
            <p className="text-2xs text-ink-400">{d.split(" ")[1]}</p>
          </div>
        ))}
      </div>
      <div className="relative grid" style={{ gridTemplateColumns: "64px repeat(5, 1fr)", gridTemplateRows: `repeat(${TIMES.length}, 64px)` }}>
        {TIMES.map((t, ri) => (
          <div key={t} className="col-start-1 border-r border-t border-line-soft px-2 py-1 text-2xs text-ink-400" style={{ gridRow: ri + 1 }}>{t}</div>
        ))}
        {TIMES.map((_, ri) => DAYS.map((__, ci) => (
          <div key={`${ri}-${ci}`} className="border-r border-t border-line-soft last:border-r-0" style={{ gridColumn: ci + 2, gridRow: ri + 1 }} />
        )))}
        {events.map((e) => (
          <div key={e.id} className={clsx("m-1 overflow-hidden rounded-lg border px-2 py-1.5", EVENT_COLORS[e.color])} style={{ gridColumn: e.day + 2, gridRow: `${e.start + 1} / span ${e.span}` }}>
            <p className="text-xs font-semibold leading-tight">{e.title}</p>
            <p className="mt-0.5 truncate text-2xs opacity-80">{e.subtitle}</p>
          </div>
        ))}
      </div>
    </Card>
  );
}

function DayView({ events, dayLabel }: { events: typeof CALENDAR_EVENTS; dayLabel: string }) {
  return (
    <Card padded={false} className="overflow-hidden">
      <div className="border-b border-line px-4 py-2.5 text-center">
        <p className="text-sm font-semibold text-ink-800">{dayLabel}</p>
      </div>
      <div className="relative grid" style={{ gridTemplateColumns: "72px 1fr", gridTemplateRows: `repeat(${TIMES.length}, 72px)` }}>
        {TIMES.map((t, ri) => (
          <div key={t} className="col-start-1 border-r border-t border-line-soft px-2 py-1 text-2xs text-ink-400" style={{ gridRow: ri + 1 }}>{t}</div>
        ))}
        {TIMES.map((_, ri) => (
          <div key={ri} className="border-t border-line-soft" style={{ gridColumn: 2, gridRow: ri + 1 }} />
        ))}
        {events.map((e) => (
          <div key={e.id} className={clsx("mx-2 my-1 overflow-hidden rounded-lg border px-3 py-2", EVENT_COLORS[e.color])} style={{ gridColumn: 2, gridRow: `${e.start + 1} / span ${e.span}` }}>
            <p className="text-sm font-semibold leading-tight">{e.title}</p>
            <p className="mt-0.5 text-xs opacity-80">{e.subtitle}</p>
          </div>
        ))}
        {events.length === 0 && (
          <div className="flex items-center justify-center py-10 text-sm text-ink-400" style={{ gridColumn: 2, gridRow: "1 / span 2" }}>
            No events scheduled this day.
          </div>
        )}
      </div>
    </Card>
  );
}

function MonthView({ events }: { events: typeof CALENDAR_EVENTS }) {
  const cols = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  // May 2025 starts on Thursday (index 3 in a Mon-first grid).
  const startOffset = 3;
  const cells: (number | null)[] = [];
  for (let i = 0; i < startOffset; i++) cells.push(null);
  for (let d = 1; d <= 31; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);

  // Events map onto the last week: day 0 -> 27 ... day 4 -> 31
  const byDate: Record<number, typeof CALENDAR_EVENTS> = {};
  events.forEach((e) => {
    const date = 27 + e.day;
    (byDate[date] = byDate[date] || []).push(e);
  });

  return (
    <Card padded={false} className="overflow-hidden">
      <div className="grid grid-cols-7 border-b border-line">
        {cols.map((c) => (
          <div key={c} className="px-3 py-2 text-center text-2xs font-semibold uppercase tracking-wide text-ink-400">{c}</div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {cells.map((d, i) => (
          <div key={i} className="min-h-[104px] border-b border-r border-line-soft p-1.5 last:border-r-0 [&:nth-child(7n)]:border-r-0">
            {d && (
              <>
                <p className="mb-1 px-1 text-xs font-medium text-ink-500">{d}</p>
                <div className="space-y-1">
                  {(byDate[d] ?? []).map((e) => (
                    <div key={e.id} className={clsx("flex items-center gap-1 truncate rounded-md px-1.5 py-1 text-2xs font-medium", EVENT_COLORS[e.color])}>
                      <span className={clsx("h-1.5 w-1.5 shrink-0 rounded-full", DOT[e.color])} />
                      <span className="truncate">{e.title}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
}
