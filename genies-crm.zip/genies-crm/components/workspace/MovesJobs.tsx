"use client";

import Link from "next/link";
import { Column } from "@/components/ui/DataTable";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Icon } from "@/components/ui/Icon";
import { EntityTable } from "./EntityTable";
import { useScoped } from "./scoped";
import { ESTIMATES, JOBS, MOVES, ROUTES } from "@/lib/data";
import { money } from "@/lib/format";
import { useApp } from "@/lib/app-context";
import { locationsFor } from "@/lib/config";
import type { Estimate, Job, Move, Route } from "@/lib/types";

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i);
  return Math.abs(h);
}
function useDefaultLoc(businessId: "move" | "window") {
  const { locationByBusiness } = useApp();
  const loc = locationByBusiness[businessId];
  return loc !== "all" ? loc : locationsFor(businessId)[0]?.id ?? "";
}

const moveColumns: Column<Move>[] = [
  {
    key: "id",
    header: "Move",
    render: (r) => (
      <Link href={`/w/move/move-details?id=${r.id}`} className="font-medium text-primary-700 hover:underline">
        {r.id}
      </Link>
    ),
  },
  { key: "customer", header: "Customer", render: (r) => <span className="font-medium text-ink-800">{r.customer}</span> },
  {
    key: "route",
    header: "Route",
    render: (r) => (
      <div className="flex items-center gap-1.5 text-ink-600">
        <span>{r.origin}</span>
        <Icon name="ArrowRight" size={13} className="text-ink-300" />
        <span>{r.destination}</span>
      </div>
    ),
  },
  { key: "date", header: "Date", render: (r) => <span className="text-ink-500">{r.date}</span> },
  { key: "crew", header: "Crew" },
  { key: "value", header: "Value", align: "right", render: (r) => <span className="font-medium text-ink-900">{money(r.value)}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Moves() {
  const rows = useScoped(MOVES, "move");
  const defaultLoc = useDefaultLoc("move");
  return (
    <EntityTable
      title="Moves"
      noun="moves"
      rows={rows}
      columns={moveColumns}
      getKey={(r) => r.id}
      searchKeys={["id", "customer", "origin", "destination", "crew"]}
      searchPlaceholder="Search moves…"
      filters={[
        { value: "all", label: "All Moves" },
        { value: "scheduled", label: "Scheduled", test: (r) => r.status === "Scheduled" },
        { value: "progress", label: "In Progress", test: (r) => r.status === "In Progress" },
        { value: "completed", label: "Completed", test: (r) => r.status === "Completed" },
      ]}
      addLabel="New Move"
      addTitle="Schedule a Move"
      addFields={[
        { key: "customer", label: "Customer", placeholder: "Jane Doe" },
        { key: "origin", label: "Origin", placeholder: "Minneapolis, MN" },
        { key: "destination", label: "Destination", placeholder: "Duluth, MN" },
        { key: "date", label: "Move date", placeholder: "Jun 5, 2025" },
      ]}
      makeRow={(f): Move => ({
        id: "MV-" + (1550 + (hash(f.customer) % 400)),
        businessId: "move",
        locationId: defaultLoc,
        customer: f.customer,
        origin: f.origin,
        destination: f.destination,
        date: f.date || "TBD",
        status: "Scheduled",
        crew: "Unassigned",
        value: 0,
      })}
    />
  );
}

const jobColumns: Column<Job>[] = [
  { key: "id", header: "Job", render: (r) => <span className="font-medium text-primary-700">{r.id}</span> },
  { key: "customer", header: "Customer", render: (r) => <span className="font-medium text-ink-800">{r.customer}</span> },
  { key: "service", header: "Service" },
  { key: "address", header: "Address", render: (r) => <span className="text-ink-500">{r.address}</span> },
  { key: "date", header: "Date", render: (r) => <span className="text-ink-500">{r.date}</span> },
  { key: "crew", header: "Crew" },
  { key: "value", header: "Value", align: "right", render: (r) => <span className="font-medium text-ink-900">{money(r.value)}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Jobs() {
  const rows = useScoped(JOBS, "window");
  const defaultLoc = useDefaultLoc("window");
  return (
    <EntityTable
      title="Jobs"
      noun="jobs"
      rows={rows}
      columns={jobColumns}
      getKey={(r) => r.id}
      searchKeys={["id", "customer", "service", "address", "crew"]}
      searchPlaceholder="Search jobs…"
      filters={[
        { value: "all", label: "All Jobs" },
        { value: "scheduled", label: "Scheduled", test: (r) => r.status === "Scheduled" },
        { value: "progress", label: "In Progress", test: (r) => r.status === "In Progress" },
        { value: "completed", label: "Completed", test: (r) => r.status === "Completed" },
      ]}
      addLabel="New Job"
      addTitle="Schedule a Job"
      addFields={[
        { key: "customer", label: "Customer", placeholder: "Jane Doe" },
        { key: "service", label: "Service", placeholder: "Exterior + Screens" },
        { key: "address", label: "Address", placeholder: "123 Main St" },
        { key: "date", label: "Date", placeholder: "Jun 5, 2025" },
      ]}
      makeRow={(f): Job => ({
        id: "JB-" + (2210 + (hash(f.customer) % 400)),
        businessId: "window",
        locationId: defaultLoc,
        customer: f.customer,
        service: f.service,
        address: f.address,
        date: f.date || "TBD",
        status: "Scheduled",
        crew: "Unassigned",
        value: 0,
      })}
    />
  );
}

const estColumns: Column<Estimate>[] = [
  { key: "id", header: "Estimate", render: (r) => <span className="font-medium text-primary-700">{r.id}</span> },
  { key: "customer", header: "Customer", render: (r) => <span className="font-medium text-ink-800">{r.customer}</span> },
  { key: "service", header: "Service" },
  { key: "amount", header: "Amount", align: "right", render: (r) => <span className="font-medium text-ink-900">{money(r.amount)}</span> },
  { key: "created", header: "Created", render: (r) => <span className="text-ink-500">{r.created}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Estimates() {
  const rows = useScoped(ESTIMATES, "window");
  const defaultLoc = useDefaultLoc("window");
  return (
    <EntityTable
      title="Estimates"
      noun="estimates"
      rows={rows}
      columns={estColumns}
      getKey={(r) => r.id}
      searchKeys={["id", "customer", "service"]}
      searchPlaceholder="Search estimates…"
      filters={[
        { value: "all", label: "All Estimates" },
        { value: "draft", label: "Draft", test: (r) => r.status === "Draft" },
        { value: "sent", label: "Sent", test: (r) => r.status === "Sent" },
        { value: "accepted", label: "Accepted", test: (r) => r.status === "Accepted" },
      ]}
      addLabel="New Estimate"
      addTitle="Create Estimate"
      addFields={[
        { key: "customer", label: "Customer", placeholder: "Jane Doe" },
        { key: "service", label: "Service", placeholder: "Full Service" },
        { key: "amount", label: "Amount ($)", placeholder: "350" },
      ]}
      makeRow={(f): Estimate => ({
        id: "ES-" + (510 + (hash(f.customer) % 400)),
        businessId: "window",
        locationId: defaultLoc,
        customer: f.customer,
        service: f.service,
        amount: Number(f.amount) || 0,
        status: "Draft",
        created: "just now",
      })}
    />
  );
}

const routeColumns: Column<Route>[] = [
  { key: "name", header: "Route", render: (r) => <span className="font-medium text-ink-900">{r.name}</span> },
  { key: "driver", header: "Driver" },
  { key: "stops", header: "Stops", align: "center" },
  { key: "distance", header: "Distance", align: "right" },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Routes() {
  const rows = useScoped(ROUTES, "window");
  const defaultLoc = useDefaultLoc("window");
  return (
    <EntityTable
      title="Routes"
      noun="routes"
      rows={rows}
      columns={routeColumns}
      getKey={(r) => r.id}
      searchKeys={["name", "driver"]}
      searchPlaceholder="Search routes…"
      filters={[
        { value: "all", label: "All Routes" },
        { value: "planned", label: "Planned", test: (r) => r.status === "Planned" },
        { value: "progress", label: "In Progress", test: (r) => r.status === "In Progress" },
        { value: "completed", label: "Completed", test: (r) => r.status === "Completed" },
      ]}
      addLabel="Plan Route"
      addTitle="Plan a Route"
      addFields={[
        { key: "name", label: "Route name", placeholder: "Downtown Loop" },
        { key: "driver", label: "Driver", placeholder: "Carlos M." },
        { key: "stops", label: "Stops", placeholder: "8" },
      ]}
      makeRow={(f): Route => ({
        id: "RT-" + (10 + (hash(f.name) % 80)),
        businessId: "window",
        locationId: defaultLoc,
        name: f.name,
        driver: f.driver,
        stops: Number(f.stops) || 0,
        distance: "—",
        status: "Planned",
      })}
    />
  );
}
