"use client";

import Link from "next/link";
import { PageHeader, Pagination } from "@/components/ui/PageHeader";
import { DataTable, Column } from "@/components/ui/DataTable";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { TableToolbar } from "./TableToolbar";
import { useScoped } from "./scoped";
import { ESTIMATES, JOBS, MOVES, ROUTES } from "@/lib/data";
import { money } from "@/lib/format";
import type { Estimate, Job, Move, Route } from "@/lib/types";

const moveColumns: Column<Move>[] = [
  {
    key: "id",
    header: "Move",
    render: (r) => (
      <Link href={`/w/move/move-details?id=${r.id}`} className="font-medium text-primary-700 hover:underline">
        {r.id}
      </Link>
    ),
  },
  { key: "customer", header: "Customer", render: (r) => <span className="font-medium text-ink-800">{r.customer}</span> },
  {
    key: "route",
    header: "Route",
    render: (r) => (
      <div className="flex items-center gap-1.5 text-ink-600">
        <span>{r.origin}</span>
        <Icon name="ArrowRight" size={13} className="text-ink-300" />
        <span>{r.destination}</span>
      </div>
    ),
  },
  { key: "date", header: "Date", render: (r) => <span className="text-ink-500">{r.date}</span> },
  { key: "crew", header: "Crew" },
  { key: "value", header: "Value", align: "right", render: (r) => <span className="font-medium text-ink-900">{money(r.value)}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Moves() {
  const rows = useScoped(MOVES, "move");
  return (
    <div>
      <PageHeader title="Moves" subtitle={`${rows.length} moves scheduled`} action={<Button icon="Plus">New Move</Button>} />
      <DataTable
        columns={moveColumns}
        rows={rows}
        getKey={(r) => r.id}
        toolbar={<TableToolbar filterOptions={[{ value: "all", label: "All Moves" }, { value: "scheduled", label: "Scheduled" }, { value: "progress", label: "In Progress" }]} searchPlaceholder="Search moves…" />}
        footer={<Pagination from={1} to={rows.length} total={rows.length} noun="moves" />}
      />
    </div>
  );
}

const jobColumns: Column<Job>[] = [
  { key: "id", header: "Job", render: (r) => <span className="font-medium text-primary-700">{r.id}</span> },
  { key: "customer", header: "Customer", render: (r) => <span className="font-medium text-ink-800">{r.customer}</span> },
  { key: "service", header: "Service" },
  { key: "address", header: "Address", render: (r) => <span className="text-ink-500">{r.address}</span> },
  { key: "date", header: "Date", render: (r) => <span className="text-ink-500">{r.date}</span> },
  { key: "crew", header: "Crew" },
  { key: "value", header: "Value", align: "right", render: (r) => <span className="font-medium text-ink-900">{money(r.value)}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Jobs() {
  const rows = useScoped(JOBS, "window");
  return (
    <div>
      <PageHeader title="Jobs" subtitle={`${rows.length} jobs scheduled`} action={<Button icon="Plus">New Job</Button>} />
      <DataTable
        columns={jobColumns}
        rows={rows}
        getKey={(r) => r.id}
        toolbar={<TableToolbar filterOptions={[{ value: "all", label: "All Jobs" }, { value: "scheduled", label: "Scheduled" }]} searchPlaceholder="Search jobs…" />}
        footer={<Pagination from={1} to={rows.length} total={rows.length} noun="jobs" />}
      />
    </div>
  );
}

const estColumns: Column<Estimate>[] = [
  { key: "id", header: "Estimate", render: (r) => <span className="font-medium text-primary-700">{r.id}</span> },
  { key: "customer", header: "Customer", render: (r) => <span className="font-medium text-ink-800">{r.customer}</span> },
  { key: "service", header: "Service" },
  { key: "amount", header: "Amount", align: "right", render: (r) => <span className="font-medium text-ink-900">{money(r.amount)}</span> },
  { key: "created", header: "Created", render: (r) => <span className="text-ink-500">{r.created}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Estimates() {
  const rows = useScoped(ESTIMATES, "window");
  return (
    <div>
      <PageHeader title="Estimates" subtitle={`${rows.length} estimates`} action={<Button icon="Plus">New Estimate</Button>} />
      <DataTable
        columns={estColumns}
        rows={rows}
        getKey={(r) => r.id}
        toolbar={<TableToolbar filterOptions={[{ value: "all", label: "All Estimates" }, { value: "sent", label: "Sent" }, { value: "accepted", label: "Accepted" }]} searchPlaceholder="Search estimates…" />}
        footer={<Pagination from={1} to={rows.length} total={rows.length} noun="estimates" />}
      />
    </div>
  );
}

const routeColumns: Column<Route>[] = [
  { key: "name", header: "Route", render: (r) => <span className="font-medium text-ink-900">{r.name}</span> },
  { key: "driver", header: "Driver" },
  { key: "stops", header: "Stops", align: "center" },
  { key: "distance", header: "Distance", align: "right" },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Routes() {
  const rows = useScoped(ROUTES, "window");
  return (
    <div>
      <PageHeader title="Routes" subtitle={`${rows.length} routes planned`} action={<Button icon="Plus">Plan Route</Button>} />
      <DataTable
        columns={routeColumns}
        rows={rows}
        getKey={(r) => r.id}
        toolbar={<TableToolbar filterOptions={[{ value: "all", label: "All Routes" }, { value: "planned", label: "Planned" }]} searchPlaceholder="Search routes…" />}
        footer={<Pagination from={1} to={rows.length} total={rows.length} noun="routes" />}
      />
    </div>
  );
}
