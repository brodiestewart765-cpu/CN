"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";
import clsx from "clsx";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { MOVES, MOVE_INVENTORY } from "@/lib/data";
import { money } from "@/lib/format";

const TABS = ["Details", "Tasks", "Documents", "Activity"];

export function MoveDetails() {
  const params = useSearchParams();
  const id = params.get("id");
  const move = MOVES.find((m) => m.id === id) ?? MOVES[0];
  const [tab, setTab] = useState("Details");

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <h1 className="page-title">Move {move.id}</h1>
          <StatusBadge status={move.status} />
        </div>
        <div className="flex items-center gap-2">
          <Button variant="secondary" icon="MessageSquare">Message</Button>
          <Button icon="Settings">Edit / Actions</Button>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <div className="space-y-5">
          <Card>
            <p className="text-2xs font-semibold uppercase tracking-wide text-ink-400">Customer</p>
            <p className="mt-2 text-sm font-semibold text-ink-900">{move.customer}</p>
            <div className="mt-2 space-y-1.5 text-sm text-ink-600">
              <p className="flex items-center gap-2"><Icon name="Phone" size={14} className="text-ink-400" /> (651) 200-4410</p>
              <p className="flex items-center gap-2"><Icon name="Mail" size={14} className="text-ink-400" /> john.smith@gmail.com</p>
            </div>
          </Card>
          <Card>
            <p className="text-2xs font-semibold uppercase tracking-wide text-ink-400">Move Details</p>
            <dl className="mt-2 space-y-2.5 text-sm">
              <Row label="Origin" value={move.origin} />
              <Row label="Destination" value={move.destination} />
              <Row label="Move Date" value={move.date} />
              <Row label="Crew" value={move.crew} />
              <Row label="Estimate" value={money(move.value)} strong />
            </dl>
          </Card>
        </div>

        <Card padded={false}>
          <div className="flex gap-1 border-b border-line px-4 pt-2">
            {TABS.map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={clsx(
                  "relative px-3 py-2.5 text-sm font-medium transition-colors",
                  tab === t ? "text-primary-700" : "text-ink-500 hover:text-ink-800"
                )}
              >
                {t}
                {tab === t && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-primary-600" />}
              </button>
            ))}
          </div>
          <div className="p-5">
            {tab === "Details" && (
              <div>
                <h4 className="text-sm font-semibold text-ink-900">Inventory</h4>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {MOVE_INVENTORY.map((it) => (
                    <div key={it} className="flex items-center gap-2 rounded-lg border border-line px-3 py-2 text-sm text-ink-700">
                      <Icon name="CheckCircle2" size={15} className="text-success-500" />
                      {it}
                    </div>
                  ))}
                </div>
                <h4 className="mt-6 text-sm font-semibold text-ink-900">Notes</h4>
                <p className="mt-2 rounded-lg bg-surface p-3 text-sm text-ink-600">
                  Customer requested extra care for antique dining table. Elevator reserved 8–11 AM at destination.
                </p>
              </div>
            )}
            {tab === "Tasks" && (
              <ul className="space-y-2 text-sm text-ink-700">
                {["Confirm crew assignment", "Reserve moving truck", "Collect deposit", "Send confirmation email"].map((t, i) => (
                  <li key={t} className="flex items-center gap-2.5 rounded-lg border border-line px-3 py-2.5">
                    <span className={clsx("flex h-5 w-5 items-center justify-center rounded-md border", i < 2 ? "border-primary-600 bg-primary-600 text-white" : "border-ink-300")}>
                      {i < 2 && <Icon name="CheckCircle2" size={13} />}
                    </span>
                    <span className={i < 2 ? "text-ink-400 line-through" : ""}>{t}</span>
                  </li>
                ))}
              </ul>
            )}
            {tab === "Documents" && (
              <div className="space-y-2">
                {["Bill of Lading.pdf", "Signed Estimate.pdf", "Inventory List.xlsx"].map((d) => (
                  <div key={d} className="flex items-center gap-3 rounded-lg border border-line px-3 py-2.5 text-sm">
                    <Icon name="FileText" size={16} className="text-primary-600" />
                    <span className="flex-1 text-ink-800">{d}</span>
                    <Icon name="Download" size={15} className="text-ink-400" />
                  </div>
                ))}
              </div>
            )}
            {tab === "Activity" && (
              <div className="space-y-3">
                {[
                  ["Move scheduled", "2 days ago"],
                  ["Deposit received", "1 day ago"],
                  ["Crew assigned — Team A", "5 hrs ago"],
                  ["Status changed to In Progress", "1 hr ago"],
                ].map(([t, time]) => (
                  <div key={t} className="flex items-center gap-3 text-sm">
                    <span className="h-2 w-2 rounded-full bg-primary-500" />
                    <span className="flex-1 text-ink-700">{t}</span>
                    <span className="text-xs text-ink-400">{time}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-ink-500">{label}</dt>
      <dd className={strong ? "font-semibold text-ink-900" : "text-ink-800"}>{value}</dd>
    </div>
  );
}
