"use client";

import { BusinessId, Employee, Vendor } from "@/lib/types";
import { Column } from "@/components/ui/DataTable";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { Icon } from "@/components/ui/Icon";
import { EntityTable } from "./EntityTable";
import { useScoped } from "./scoped";
import { EMPLOYEES, VENDORS } from "@/lib/data";
import { useApp } from "@/lib/app-context";
import { locationsFor } from "@/lib/config";

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i);
  return Math.abs(h);
}
function useDefaultLoc(businessId: BusinessId) {
  const { locationByBusiness } = useApp();
  const loc = locationByBusiness[businessId];
  return loc !== "all" ? loc : locationsFor(businessId)[0]?.id ?? "";
}

const empColumns: Column<Employee>[] = [
  {
    key: "name",
    header: "Employee",
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <Avatar name={r.name} size={30} />
        <div>
          <p className="font-medium text-ink-900">{r.name}</p>
          <p className="text-xs text-ink-400">{r.role}</p>
        </div>
      </div>
    ),
  },
  { key: "phone", header: "Phone" },
  { key: "email", header: "Email", render: (r) => <span className="text-ink-500">{r.email}</span> },
  { key: "jobsToday", header: "Jobs Today", align: "center" },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Employees({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(EMPLOYEES, businessId);
  const defaultLoc = useDefaultLoc(businessId);
  return (
    <EntityTable
      title="Employees"
      noun="employees"
      rows={rows}
      columns={empColumns}
      getKey={(r) => r.id}
      searchKeys={["name", "role", "phone", "email"]}
      searchPlaceholder="Search employees…"
      filters={[
        { value: "all", label: "All Roles" },
        { value: "active", label: "Active", test: (r) => r.status === "Active" },
        { value: "leave", label: "On Leave", test: (r) => r.status === "On Leave" },
      ]}
      addLabel="Add Employee"
      addTitle="Add New Employee"
      addFields={[
        { key: "name", label: "Full name", placeholder: "Jane Doe" },
        { key: "role", label: "Role", placeholder: "Mover" },
        { key: "phone", label: "Phone", placeholder: "(612) 555-0100", type: "tel" },
        { key: "email", label: "Email", placeholder: "jane@company.com", type: "email" },
      ]}
      makeRow={(f): Employee => ({
        id: "E-" + (20 + (hash(f.name) % 80)),
        businessId,
        locationId: defaultLoc,
        name: f.name,
        role: f.role || "Staff",
        phone: f.phone,
        email: f.email,
        status: "Active",
        jobsToday: 0,
      })}
    />
  );
}

const venColumns: Column<Vendor>[] = [
  {
    key: "name",
    header: "Vendor",
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface text-ink-500">
          <Icon name="Building2" size={16} />
        </span>
        <span className="font-medium text-ink-900">{r.name}</span>
      </div>
    ),
  },
  { key: "category", header: "Category" },
  { key: "contact", header: "Contact" },
  { key: "phone", header: "Phone", render: (r) => <span className="text-ink-500">{r.phone}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Vendors({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(VENDORS, businessId);
  const defaultLoc = useDefaultLoc(businessId);
  return (
    <EntityTable
      title="Vendors"
      noun="vendors"
      rows={rows}
      columns={venColumns}
      getKey={(r) => r.id}
      searchKeys={["name", "category", "contact", "phone"]}
      searchPlaceholder="Search vendors…"
      filters={[
        { value: "all", label: "All Vendors" },
        { value: "active", label: "Active", test: (r) => r.status === "Active" },
        { value: "inactive", label: "Inactive", test: (r) => r.status === "Inactive" },
      ]}
      addLabel="Add Vendor"
      addTitle="Add New Vendor"
      addFields={[
        { key: "name", label: "Vendor name", placeholder: "BoxDepot Supplies" },
        { key: "category", label: "Category", placeholder: "Packing Materials" },
        { key: "contact", label: "Contact", placeholder: "Rita Order" },
        { key: "phone", label: "Phone", placeholder: "(612) 555-0100", type: "tel" },
      ]}
      makeRow={(f): Vendor => ({
        id: "V-" + (20 + (hash(f.name) % 80)),
        businessId,
        locationId: defaultLoc,
        name: f.name,
        category: f.category || "General",
        contact: f.contact,
        phone: f.phone,
        status: "Active",
      })}
    />
  );
}
