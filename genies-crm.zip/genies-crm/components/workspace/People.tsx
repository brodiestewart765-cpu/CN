"use client";

import { BusinessId, Employee, Vendor } from "@/lib/types";
import { PageHeader, Pagination } from "@/components/ui/PageHeader";
import { DataTable, Column } from "@/components/ui/DataTable";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { TableToolbar } from "./TableToolbar";
import { useScoped } from "./scoped";
import { EMPLOYEES, VENDORS } from "@/lib/data";

const empColumns: Column<Employee>[] = [
  {
    key: "name",
    header: "Employee",
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <Avatar name={r.name} size={30} />
        <div>
          <p className="font-medium text-ink-900">{r.name}</p>
          <p className="text-xs text-ink-400">{r.role}</p>
        </div>
      </div>
    ),
  },
  { key: "phone", header: "Phone" },
  { key: "email", header: "Email", render: (r) => <span className="text-ink-500">{r.email}</span> },
  { key: "jobsToday", header: "Jobs Today", align: "center" },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Employees({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(EMPLOYEES, businessId);
  return (
    <div>
      <PageHeader title="Employees" subtitle={`${rows.length} team members`} action={<Button icon="Plus">Add Employee</Button>} />
      <DataTable
        columns={empColumns}
        rows={rows}
        getKey={(r) => r.id}
        toolbar={<TableToolbar filterOptions={[{ value: "all", label: "All Roles" }, { value: "active", label: "Active" }]} searchPlaceholder="Search employees…" />}
        footer={<Pagination from={1} to={rows.length} total={rows.length} noun="employees" />}
      />
    </div>
  );
}

const venColumns: Column<Vendor>[] = [
  {
    key: "name",
    header: "Vendor",
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface text-ink-500">
          <Icon name="Building2" size={16} />
        </span>
        <span className="font-medium text-ink-900">{r.name}</span>
      </div>
    ),
  },
  { key: "category", header: "Category" },
  { key: "contact", header: "Contact" },
  { key: "phone", header: "Phone", render: (r) => <span className="text-ink-500">{r.phone}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Vendors({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(VENDORS, businessId);
  return (
    <div>
      <PageHeader title="Vendors" subtitle={`${rows.length} vendors`} action={<Button icon="Plus">Add Vendor</Button>} />
      <DataTable
        columns={venColumns}
        rows={rows}
        getKey={(r) => r.id}
        toolbar={<TableToolbar filterOptions={[{ value: "all", label: "All Vendors" }, { value: "active", label: "Active" }]} searchPlaceholder="Search vendors…" />}
        footer={<Pagination from={1} to={rows.length} total={rows.length} noun="vendors" />}
      />
    </div>
  );
}
