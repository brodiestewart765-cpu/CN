"use client";

import { useState } from "react";
import { Dropdown, DropdownOption } from "@/components/ui/Dropdown";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";

export function TableToolbar({
  filterOptions,
  filterValue,
  onFilter,
  searchPlaceholder = "Search…",
  addLabel,
}: {
  filterOptions?: DropdownOption[];
  filterValue?: string;
  onFilter?: (v: string) => void;
  searchPlaceholder?: string;
  addLabel?: string;
}) {
  const [q, setQ] = useState("");
  return (
    <>
      {filterOptions && (
        <Dropdown
          options={filterOptions}
          value={filterValue ?? filterOptions[0].value}
          onChange={onFilter ?? (() => {})}
          leadingIcon="Filter"
          className="w-[150px]"
        />
      )}
      <div className="flex h-9 min-w-[200px] flex-1 items-center gap-2 rounded-lg border border-line bg-surface px-3 text-sm text-ink-400 focus-within:border-primary-300 focus-within:bg-white sm:max-w-xs">
        <Icon name="Search" size={15} />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={searchPlaceholder}
          className="w-full bg-transparent text-ink-800 placeholder:text-ink-400 focus:outline-none"
        />
      </div>
      {addLabel && (
        <Button icon="Plus" className="ml-auto">
          {addLabel}
        </Button>
      )}
    </>
  );
}
