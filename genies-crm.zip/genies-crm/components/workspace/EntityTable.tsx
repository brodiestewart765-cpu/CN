"use client";

import { useMemo, useState } from "react";
import { Column, DataTable } from "@/components/ui/DataTable";
import { PageHeader, Pagination } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { Dropdown } from "@/components/ui/Dropdown";
import { Icon } from "@/components/ui/Icon";
import { Modal } from "@/components/ui/Modal";

export interface FilterDef<T> {
  value: string;
  label: string;
  test?: (row: T) => boolean; // omit on the "all" option
}

export interface AddField {
  key: string;
  label: string;
  placeholder?: string;
  type?: "text" | "email" | "tel";
}

export function EntityTable<T extends Record<string, any>>({
  title,
  noun,
  rows,
  columns,
  getKey,
  searchKeys,
  searchPlaceholder,
  filters,
  addLabel,
  addTitle,
  addFields,
  makeRow,
}: {
  title: string;
  noun: string;
  rows: T[]; // location/business-scoped, reactive
  columns: Column<T>[];
  getKey: (row: T) => string;
  searchKeys: string[];
  searchPlaceholder?: string;
  filters?: FilterDef<T>[];
  addLabel?: string;
  addTitle?: string;
  addFields?: AddField[];
  makeRow?: (form: Record<string, string>) => T;
}) {
  const [extra, setExtra] = useState<T[]>([]);
  const [query, setQuery] = useState("");
  const [filterValue, setFilterValue] = useState(filters?.[0]?.value ?? "all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});

  const all = useMemo(() => [...extra, ...rows], [extra, rows]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const activeFilter = filters?.find((f) => f.value === filterValue);
    return all.filter((row) => {
      const matchesQuery =
        q === "" ||
        searchKeys.some((k) =>
          String(row[k] ?? "").toLowerCase().includes(q)
        );
      const matchesFilter =
        !activeFilter || !activeFilter.test || activeFilter.test(row);
      return matchesQuery && matchesFilter;
    });
  }, [all, query, filterValue, filters, searchKeys]);

  function submitAdd() {
    if (!makeRow) return;
    const row = makeRow(form);
    setExtra((prev) => [row, ...prev]);
    setForm({});
    setOpen(false);
  }

  const canSubmit =
    !addFields || addFields.every((f) => (form[f.key] ?? "").trim() !== "");

  return (
    <div>
      <PageHeader
        title={title}
        subtitle={`${filtered.length} ${noun}`}
        action={
          addLabel && (
            <Button icon="Plus" onClick={() => setOpen(true)}>
              {addLabel}
            </Button>
          )
        }
      />

      <DataTable
        columns={columns}
        rows={filtered}
        getKey={getKey}
        toolbar={
          <>
            {filters && (
              <Dropdown
                options={filters.map((f) => ({ value: f.value, label: f.label }))}
                value={filterValue}
                onChange={setFilterValue}
                leadingIcon="Filter"
                className="w-[160px]"
              />
            )}
            <div className="flex h-9 min-w-[200px] flex-1 items-center gap-2 rounded-lg border border-line bg-surface px-3 text-sm text-ink-400 focus-within:border-primary-300 focus-within:bg-white sm:max-w-xs">
              <Icon name="Search" size={15} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={searchPlaceholder ?? `Search ${noun}…`}
                className="w-full bg-transparent text-ink-800 placeholder:text-ink-400 focus:outline-none"
              />
              {query && (
                <button onClick={() => setQuery("")} className="text-ink-400 hover:text-ink-700">
                  <Icon name="X" size={14} />
                </button>
              )}
            </div>
          </>
        }
        footer={
          <Pagination from={filtered.length ? 1 : 0} to={filtered.length} total={filtered.length} noun={noun} />
        }
        emptyLabel={query ? `No ${noun} match “${query}”` : `No ${noun} yet`}
      />

      {addFields && makeRow && (
        <Modal
          open={open}
          onClose={() => setOpen(false)}
          title={addTitle ?? addLabel ?? "Add"}
          footer={
            <>
              <Button variant="secondary" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button onClick={submitAdd} disabled={!canSubmit}>
                Add
              </Button>
            </>
          }
        >
          <div className="space-y-4">
            {addFields.map((f) => (
              <div key={f.key}>
                <label className="mb-1 block text-sm font-medium text-ink-700">
                  {f.label}
                </label>
                <input
                  type={f.type ?? "text"}
                  value={form[f.key] ?? ""}
                  placeholder={f.placeholder}
                  onChange={(e) =>
                    setForm((prev) => ({ ...prev, [f.key]: e.target.value }))
                  }
                  className="h-10 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
                />
              </div>
            ))}
            <p className="text-xs text-ink-400">
              Note: added records are shown for this session. Saving to a
              database comes in a later phase.
            </p>
          </div>
        </Modal>
      )}
    </div>
  );
}
