"use client";

import { BusinessId, Lead } from "@/lib/types";
import { Column } from "@/components/ui/DataTable";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { EntityTable } from "./EntityTable";
import { useScoped } from "./scoped";
import { LEADS } from "@/lib/data";
import { useApp } from "@/lib/app-context";
import { locationsFor } from "@/lib/config";

const columns: Column<Lead>[] = [
  {
    key: "name",
    header: "Lead",
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <Avatar name={r.name} size={30} />
        <span className="font-medium text-ink-900">{r.name}</span>
      </div>
    ),
  },
  {
    key: "contact",
    header: "Contact",
    render: (r) => (
      <div>
        <p className="text-ink-700">{r.phone}</p>
        <p className="text-xs text-ink-400">{r.email}</p>
      </div>
    ),
  },
  { key: "source", header: "Source" },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
  { key: "lastActivity", header: "Last Activity", render: (r) => <span className="text-ink-500">{r.lastActivity}</span> },
  { key: "owner", header: "Owner" },
];

export function Leads({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(LEADS, businessId);
  const { locationByBusiness } = useApp();
  const loc = locationByBusiness[businessId];
  const defaultLoc =
    loc !== "all" ? loc : locationsFor(businessId)[0]?.id ?? "";

  return (
    <EntityTable
      title="Leads"
      noun="leads"
      rows={rows}
      columns={columns}
      getKey={(r) => r.id}
      searchKeys={["name", "phone", "email", "source", "owner"]}
      searchPlaceholder="Search leads…"
      filters={[
        { value: "all", label: "All Leads" },
        { value: "new", label: "New", test: (r) => r.status === "New" },
        { value: "contacted", label: "Contacted", test: (r) => r.status === "Contacted" },
        { value: "progress", label: "In Progress", test: (r) => r.status === "In Progress" },
        { value: "qualified", label: "Qualified", test: (r) => r.status === "Qualified" },
      ]}
      addLabel="Add Lead"
      addTitle="Add New Lead"
      addFields={[
        { key: "name", label: "Full name", placeholder: "Jane Doe" },
        { key: "phone", label: "Phone", placeholder: "(612) 555-0100", type: "tel" },
        { key: "email", label: "Email", placeholder: "jane@email.com", type: "email" },
        { key: "source", label: "Source", placeholder: "Google Ads" },
      ]}
      makeRow={(f): Lead => ({
        id: "L-" + Math.floor(1000 + Math.abs(hash(f.name + f.phone)) % 9000),
        businessId,
        locationId: defaultLoc,
        name: f.name,
        phone: f.phone,
        email: f.email,
        source: f.source || "Manual",
        status: "New",
        lastActivity: "just now",
        owner: "You",
      })}
    />
  );
}

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i);
  return h;
}
