"use client";

import { BusinessId } from "@/lib/types";
import { PageHeader, Pagination } from "@/components/ui/PageHeader";
import { DataTable, Column } from "@/components/ui/DataTable";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { TableToolbar } from "./TableToolbar";
import { useScoped } from "./scoped";
import { LEADS } from "@/lib/data";
import type { Lead } from "@/lib/types";

const columns: Column<Lead>[] = [
  {
    key: "name",
    header: "Lead",
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <Avatar name={r.name} size={30} />
        <span className="font-medium text-ink-900">{r.name}</span>
      </div>
    ),
  },
  {
    key: "contact",
    header: "Contact",
    render: (r) => (
      <div>
        <p className="text-ink-700">{r.phone}</p>
        <p className="text-xs text-ink-400">{r.email}</p>
      </div>
    ),
  },
  { key: "source", header: "Source" },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
  { key: "lastActivity", header: "Last Activity", render: (r) => <span className="text-ink-500">{r.lastActivity}</span> },
  { key: "owner", header: "Owner" },
];

export function Leads({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(LEADS, businessId);
  return (
    <div>
      <PageHeader
        title="Leads"
        subtitle={`${rows.length} leads in your pipeline`}
        action={<Button icon="Plus">Add Lead</Button>}
      />
      <DataTable
        columns={columns}
        rows={rows}
        getKey={(r) => r.id}
        toolbar={
          <TableToolbar
            filterOptions={[
              { value: "all", label: "All Leads" },
              { value: "new", label: "New" },
              { value: "progress", label: "In Progress" },
            ]}
            searchPlaceholder="Search leads…"
          />
        }
        footer={<Pagination from={1} to={rows.length} total={rows.length} noun="leads" />}
      />
    </div>
  );
}
