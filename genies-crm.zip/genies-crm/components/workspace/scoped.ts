"use client";

import { BusinessId } from "@/lib/types";
import { useApp } from "@/lib/app-context";
import { byBusiness, filterByLocation } from "@/lib/data";

// Location-aware scoping hook — the single client-side entry point that every
// workspace page uses so location filtering behaves identically everywhere.
export function useScoped<T extends { businessId: BusinessId; locationId: string }>(
  rows: T[],
  businessId: BusinessId
): T[] {
  const { locationByBusiness } = useApp();
  const loc = locationByBusiness[businessId];
  return filterByLocation(byBusiness(rows, businessId), loc);
}
