"use client";

import { BusinessId, Customer } from "@/lib/types";
import { PageHeader, Pagination } from "@/components/ui/PageHeader";
import { DataTable, Column } from "@/components/ui/DataTable";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { TableToolbar } from "./TableToolbar";
import { useScoped } from "./scoped";
import { CUSTOMERS } from "@/lib/data";
import { money } from "@/lib/format";

const columns: Column<Customer>[] = [
  {
    key: "name",
    header: "Customer",
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <Avatar name={r.name} size={30} />
        <div>
          <p className="font-medium text-ink-900">{r.name}</p>
          <p className="text-xs text-ink-400">{r.email}</p>
        </div>
      </div>
    ),
  },
  { key: "phone", header: "Phone" },
  { key: "address", header: "Address", render: (r) => <span className="text-ink-500">{r.address}</span> },
  { key: "jobs", header: "Jobs", align: "center" },
  { key: "totalSpend", header: "Total Spend", align: "right", render: (r) => <span className="font-medium text-ink-900">{money(r.totalSpend)}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Customers({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(CUSTOMERS, businessId);
  return (
    <div>
      <PageHeader
        title="Customers"
        subtitle={`${rows.length} active customers`}
        action={<Button icon="Plus">Add Customer</Button>}
      />
      <DataTable
        columns={columns}
        rows={rows}
        getKey={(r) => r.id}
        toolbar={<TableToolbar filterOptions={[{ value: "all", label: "All Customers" }, { value: "active", label: "Active" }]} searchPlaceholder="Search customers…" />}
        footer={<Pagination from={1} to={rows.length} total={rows.length} noun="customers" />}
      />
    </div>
  );
}
