"use client";

import { BusinessId, Customer } from "@/lib/types";
import { Column } from "@/components/ui/DataTable";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { EntityTable } from "./EntityTable";
import { useScoped } from "./scoped";
import { CUSTOMERS } from "@/lib/data";
import { money } from "@/lib/format";
import { useApp } from "@/lib/app-context";
import { locationsFor } from "@/lib/config";

const columns: Column<Customer>[] = [
  {
    key: "name",
    header: "Customer",
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <Avatar name={r.name} size={30} />
        <div>
          <p className="font-medium text-ink-900">{r.name}</p>
          <p className="text-xs text-ink-400">{r.email}</p>
        </div>
      </div>
    ),
  },
  { key: "phone", header: "Phone" },
  { key: "address", header: "Address", render: (r) => <span className="text-ink-500">{r.address}</span> },
  { key: "jobs", header: "Jobs", align: "center" },
  { key: "totalSpend", header: "Total Spend", align: "right", render: (r) => <span className="font-medium text-ink-900">{money(r.totalSpend)}</span> },
  { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

export function Customers({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(CUSTOMERS, businessId);
  const { locationByBusiness } = useApp();
  const loc = locationByBusiness[businessId];
  const defaultLoc = loc !== "all" ? loc : locationsFor(businessId)[0]?.id ?? "";

  return (
    <EntityTable
      title="Customers"
      noun="customers"
      rows={rows}
      columns={columns}
      getKey={(r) => r.id}
      searchKeys={["name", "phone", "email", "address"]}
      searchPlaceholder="Search customers…"
      filters={[
        { value: "all", label: "All Customers" },
        { value: "active", label: "Active", test: (r) => r.status === "Active" },
        { value: "inactive", label: "Inactive", test: (r) => r.status === "Inactive" },
      ]}
      addLabel="Add Customer"
      addTitle="Add New Customer"
      addFields={[
        { key: "name", label: "Full name", placeholder: "Jane Doe" },
        { key: "phone", label: "Phone", placeholder: "(612) 555-0100", type: "tel" },
        { key: "email", label: "Email", placeholder: "jane@email.com", type: "email" },
        { key: "address", label: "Address", placeholder: "123 Main St, City" },
      ]}
      makeRow={(f): Customer => ({
        id: "C-" + Math.floor(3000 + Math.abs(hash(f.name)) % 6000),
        businessId,
        locationId: defaultLoc,
        name: f.name,
        phone: f.phone,
        email: f.email,
        address: f.address,
        jobs: 0,
        totalSpend: 0,
        status: "Active",
        since: "just now",
      })}
    />
  );
}

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i);
  return h;
}
