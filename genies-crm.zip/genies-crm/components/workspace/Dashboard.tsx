"use client";

import Link from "next/link";
import { BusinessId } from "@/lib/types";
import { KpiCard } from "@/components/ui/KpiCard";
import { Card } from "@/components/ui/Card";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Icon } from "@/components/ui/Icon";
import { Dropdown } from "@/components/ui/Dropdown";
import { RevenueBarChart } from "@/components/charts/Charts";
import { useScoped } from "./scoped";
import { JOBS, LEADS, MOVES } from "@/lib/data";
import { money } from "@/lib/format";
import { useState } from "react";

const REV_SERIES = [
  { label: "W1", value: 12400 },
  { label: "W2", value: 9800 },
  { label: "W3", value: 15200 },
  { label: "W4", value: 11300 },
  { label: "W5", value: 18600 },
  { label: "W6", value: 14100 },
  { label: "W7", value: 21200 },
  { label: "W8", value: 17400 },
];

export function Dashboard({ businessId }: { businessId: BusinessId }) {
  const [range, setRange] = useState("30d");
  const isMove = businessId === "move";

  const moves = useScoped(MOVES, "move");
  const jobs = useScoped(JOBS, "window");
  const leads = useScoped(LEADS, businessId);
  const items = isMove ? moves : jobs;

  const revenue = items.reduce((a, i) => a + i.value, 0) + (isMove ? 42300 : 33520);
  const active = items.filter((i) => i.status !== "Completed").length;
  const todays = Math.max(items.length - 1, 0);

  const jobNoun = isMove ? "Moves" : "Jobs";
  const jobNounSingular = isMove ? "Move" : "Job";

  const schedule = items.slice(0, 5);

  return (
    <div>
      <h1 className="page-title mb-5">Dashboard</h1>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          label="Revenue (MTD)"
          value={money(revenue)}
          icon="CircleDollarSign"
          iconTone="green"
          delta="14%"
          sublabel="vs last month"
        />
        <KpiCard
          label={`Active ${jobNoun}`}
          value={`${active}`}
          icon={isMove ? "Truck" : "Sparkles"}
          iconTone="blue"
          delta="6%"
          sublabel="in progress"
        />
        <KpiCard
          label={`Today's ${jobNoun}`}
          value={`${todays}`}
          icon="Clock"
          iconTone="violet"
          delta="3%"
          sublabel="scheduled"
        />
        <KpiCard
          label="New Leads"
          value={`${leads.length}`}
          icon="UserPlus"
          iconTone="violet"
          delta="9%"
          sublabel="this week"
        />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-medium text-ink-500">Revenue Overview</p>
              <p className="mt-1 text-2xl font-semibold tracking-tight text-ink-900">
                {money(revenue)}
              </p>
            </div>
            <Dropdown
              options={[
                { value: "7d", label: "Last 7 days" },
                { value: "30d", label: "Last 30 days" },
                { value: "90d", label: "Last 90 days" },
              ]}
              value={range}
              onChange={setRange}
              className="w-[150px]"
              align="right"
            />
          </div>
          <RevenueBarChart data={REV_SERIES} />
        </Card>

        <Card padded={false}>
          <div className="flex items-center justify-between px-5 pb-3 pt-5">
            <h3 className="text-md font-semibold text-ink-900">Today&rsquo;s Schedule</h3>
            <Link href={`/w/${businessId}/calendar`} className="text-sm font-medium text-primary-600 hover:text-primary-700">
              View
            </Link>
          </div>
          <div className="divide-y divide-line-soft">
            {schedule.map((s: any) => (
              <div key={s.id} className="flex items-center gap-3 px-5 py-[11px] hover:bg-surface-sunken">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-surface text-ink-500">
                  <Icon name={isMove ? "Truck" : "SquareStack"} size={15} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-ink-800">{s.id}</p>
                  <p className="truncate text-xs text-ink-500">{s.customer}</p>
                </div>
                <StatusBadge status={s.status} />
              </div>
            ))}
            {schedule.length === 0 && (
              <p className="px-5 py-8 text-center text-sm text-ink-400">
                No {jobNounSingular.toLowerCase()}s for this location.
              </p>
            )}
          </div>
        </Card>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2" padded={false}>
          <div className="flex items-center justify-between px-5 pb-3 pt-5">
            <h3 className="text-md font-semibold text-ink-900">Recent Leads</h3>
            <Link href={`/w/${businessId}/leads`} className="text-sm font-medium text-primary-600 hover:text-primary-700">
              View all
            </Link>
          </div>
          <div className="divide-y divide-line-soft">
            {leads.slice(0, 4).map((l) => (
              <div key={l.id} className="flex items-center gap-3 px-5 py-3 hover:bg-surface-sunken">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-ink-800">{l.name}</p>
                  <p className="truncate text-xs text-ink-500">{l.source} · {l.lastActivity}</p>
                </div>
                <StatusBadge status={l.status} />
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <p className="text-xs font-medium text-ink-500">Conversion this month</p>
          <div className="mt-4 space-y-4">
            {[
              { label: "Leads", val: 100, color: "bg-primary-200" },
              { label: "Contacted", val: 72, color: "bg-primary-300" },
              { label: "Qualified", val: 48, color: "bg-primary-400" },
              { label: `Won ${jobNoun}`, val: 31, color: "bg-primary-600" },
            ].map((s) => (
              <div key={s.label}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="text-ink-600">{s.label}</span>
                  <span className="font-medium text-ink-800">{s.val}%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-surface">
                  <div className={`h-full rounded-full ${s.color}`} style={{ width: `${s.val}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
