"use client";

import { useState } from "react";
import clsx from "clsx";
import { BusinessId } from "@/lib/types";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { BUSINESSES, USERS, locationsFor } from "@/lib/config";

const TABS = [
  { id: "general", label: "General", icon: "Settings" },
  { id: "locations", label: "Locations", icon: "MapPin" },
  { id: "users", label: "Users & Permissions", icon: "Users" },
  { id: "notifications", label: "Notifications", icon: "Bell" },
  { id: "integrations", label: "Integrations", icon: "Grip" },
  { id: "billing", label: "Billing", icon: "Wallet" },
];

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-1 gap-1 sm:grid-cols-[180px_1fr] sm:items-center sm:gap-4">
      <label className="text-sm font-medium text-ink-600">{label}</label>
      <input
        defaultValue={value}
        className="h-10 rounded-lg border border-line bg-white px-3 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
      />
    </div>
  );
}

export function Settings({ businessId }: { businessId: BusinessId }) {
  const [tab, setTab] = useState("general");
  const b = BUSINESSES[businessId];
  const [locations, setLocations] = useState(
    locationsFor(businessId).map((l) => ({ ...l }))
  );

  function toggle(id: string) {
    setLocations((ls) => ls.map((l) => (l.id === id ? { ...l, disabled: !l.disabled } : l)));
  }

  return (
    <div>
      <PageHeader title="Settings" subtitle={`${b.name} workspace settings`} />
      <div className="grid gap-5 lg:grid-cols-[220px_1fr]">
        <nav className="card h-fit p-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={clsx(
                "flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left text-sm font-medium transition-colors",
                tab === t.id ? "bg-primary-50 text-primary-700" : "text-ink-600 hover:bg-surface"
              )}
            >
              <Icon name={t.icon} size={16} className={tab === t.id ? "text-primary-600" : "text-ink-400"} />
              {t.label}
            </button>
          ))}
        </nav>

        <div className="card p-6">
          {tab === "general" && (
            <div className="max-w-2xl space-y-5">
              <h3 className="text-md font-semibold text-ink-900">Business Details</h3>
              <Field label="Business Name" value={b.name} />
              <Field label="Business Email" value={`hello@${businessId}scrm.com`} />
              <Field label="Phone" value="(612) 555-0480" />
              <div className="grid grid-cols-1 gap-1 sm:grid-cols-[180px_1fr] sm:gap-4">
                <label className="pt-2 text-sm font-medium text-ink-600">Address</label>
                <textarea
                  defaultValue={"721 Nicollet Ave\nMinneapolis, MN 55402"}
                  rows={2}
                  className="rounded-lg border border-line bg-white px-3 py-2 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
                />
              </div>
              <div className="pt-1">
                <Button>Save Changes</Button>
              </div>
            </div>
          )}

          {tab === "locations" && (
            <div>
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-md font-semibold text-ink-900">Locations</h3>
                  <p className="mt-0.5 text-xs text-ink-500">Add, rename, disable or remove locations for {b.name}.</p>
                </div>
                <Button
                  icon="Plus"
                  onClick={() =>
                    setLocations((ls) => [
                      ...ls,
                      { id: `new-${ls.length + 1}`, businessId, name: `Loco ${ls.length + 1}`, city: "New City" },
                    ])
                  }
                >
                  Add Location
                </Button>
              </div>
              <div className="divide-y divide-line-soft rounded-xl border border-line">
                {locations.map((l) => (
                  <div key={l.id} className="flex items-center gap-3 px-4 py-3">
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-50 text-primary-600">
                      <Icon name="MapPin" size={16} />
                    </span>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-ink-900">{l.name}</p>
                      <p className="text-xs text-ink-400">{l.city}</p>
                    </div>
                    <StatusBadge status={l.disabled ? "Inactive" : "Active"} />
                    <button className="rounded-md p-1.5 text-ink-400 hover:bg-surface hover:text-ink-700" title="Rename">
                      <Icon name="FileText" size={15} />
                    </button>
                    <button onClick={() => toggle(l.id)} className="rounded-md p-1.5 text-ink-400 hover:bg-surface hover:text-ink-700" title="Disable">
                      <Icon name="PanelLeftClose" size={15} />
                    </button>
                    <button
                      onClick={() => setLocations((ls) => ls.filter((x) => x.id !== l.id))}
                      className="rounded-md p-1.5 text-ink-400 hover:bg-danger-50 hover:text-danger-500"
                      title="Delete"
                    >
                      <Icon name="X" size={15} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "users" && (
            <div>
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-md font-semibold text-ink-900">Users &amp; Permissions</h3>
                  <p className="mt-0.5 text-xs text-ink-500">Owners have full access. Add users scoped to a business &amp; location.</p>
                </div>
                <Button icon="Plus">Invite User</Button>
              </div>
              <div className="divide-y divide-line-soft rounded-xl border border-line">
                {USERS.map((u) => (
                  <div key={u.id} className="flex items-center gap-3 px-4 py-3">
                    <Avatar name={u.name} size={36} />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-ink-900">{u.name}</p>
                      <p className="text-xs text-ink-400">{u.email}</p>
                    </div>
                    <StatusBadge status="Active" />
                    <span className="rounded-full bg-primary-50 px-2.5 py-0.5 text-2xs font-medium capitalize text-primary-700">
                      {u.role}
                    </span>
                    <span className="hidden text-xs text-ink-400 sm:block">All businesses · All locations</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {["notifications", "integrations", "billing"].includes(tab) && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-surface text-ink-400">
                <Icon name={TABS.find((t) => t.id === tab)!.icon} size={22} />
              </span>
              <p className="mt-3 text-sm font-medium text-ink-800 capitalize">{tab}</p>
              <p className="mt-1 max-w-xs text-xs text-ink-400">
                This section is part of a later phase and will be configured soon.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
