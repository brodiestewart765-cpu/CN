"use client";

import { BusinessId, DocItem } from "@/lib/types";
import { PageHeader, Pagination } from "@/components/ui/PageHeader";
import { DataTable, Column } from "@/components/ui/DataTable";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { Avatar } from "@/components/ui/Avatar";
import { TableToolbar } from "./TableToolbar";
import { useScoped } from "./scoped";
import { DOCS, REVIEWS } from "@/lib/data";

const docColumns: Column<DocItem>[] = [
  {
    key: "name",
    header: "Document",
    render: (r) => (
      <div className="flex items-center gap-2.5">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-50 text-primary-600">
          <Icon name="FileText" size={16} />
        </span>
        <span className="font-medium text-ink-900">{r.name}</span>
      </div>
    ),
  },
  { key: "type", header: "Type" },
  { key: "owner", header: "Owner" },
  { key: "size", header: "Size", render: (r) => <span className="text-ink-500">{r.size}</span> },
  { key: "updated", header: "Updated", render: (r) => <span className="text-ink-500">{r.updated}</span> },
];

export function Documents({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(DOCS, businessId);
  return (
    <div>
      <PageHeader title="Documents" subtitle={`${rows.length} files`} action={<Button icon="Upload">Upload</Button>} />
      <DataTable
        columns={docColumns}
        rows={rows}
        getKey={(r) => r.id}
        toolbar={<TableToolbar filterOptions={[{ value: "all", label: "All Types" }, { value: "contract", label: "Contracts" }]} searchPlaceholder="Search documents…" />}
        footer={<Pagination from={1} to={rows.length} total={rows.length} noun="documents" />}
      />
    </div>
  );
}

function Stars({ n }: { n: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Icon key={i} name="Star" size={14} className={i <= n ? "text-warning-500" : "text-ink-300"} strokeWidth={i <= n ? 0 : 1.8} />
      ))}
    </div>
  );
}

export function Reviews({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(REVIEWS, businessId);
  const avg = rows.length ? (rows.reduce((a, r) => a + r.rating, 0) / rows.length).toFixed(1) : "—";
  return (
    <div>
      <PageHeader title="Reviews" subtitle={`${rows.length} reviews`} action={<Button variant="secondary" icon="ExternalLink">View on Google</Button>} />

      <div className="mb-5 grid gap-4 sm:grid-cols-3">
        <Card>
          <p className="text-xs font-medium text-ink-500">Average Rating</p>
          <div className="mt-2 flex items-center gap-2">
            <span className="text-3xl font-semibold text-ink-900">{avg}</span>
            <Icon name="Star" size={22} className="text-warning-500" strokeWidth={0} />
          </div>
        </Card>
        <Card>
          <p className="text-xs font-medium text-ink-500">Total Reviews</p>
          <p className="mt-2 text-3xl font-semibold text-ink-900">{rows.length}</p>
        </Card>
        <Card>
          <p className="text-xs font-medium text-ink-500">5-Star Reviews</p>
          <p className="mt-2 text-3xl font-semibold text-ink-900">{rows.filter((r) => r.rating === 5).length}</p>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {rows.map((r) => (
          <Card key={r.id}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Avatar name={r.author} size={34} />
                <div>
                  <p className="text-sm font-semibold text-ink-900">{r.author}</p>
                  <p className="text-2xs text-ink-400">{r.source} · {r.date}</p>
                </div>
              </div>
              <Stars n={r.rating} />
            </div>
            <p className="mt-3 text-sm text-ink-600">&ldquo;{r.text}&rdquo;</p>
          </Card>
        ))}
        {rows.length === 0 && <p className="py-10 text-center text-sm text-ink-400">No reviews for this location.</p>}
      </div>
    </div>
  );
}
