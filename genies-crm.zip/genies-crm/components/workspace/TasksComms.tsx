"use client";

import { useMemo, useState } from "react";
import { BusinessId, TaskItem } from "@/lib/types";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { Modal } from "@/components/ui/Modal";
import { useScoped } from "./scoped";
import { MESSAGES, TASKS } from "@/lib/data";

export function Tasks({ businessId }: { businessId: BusinessId }) {
  const scoped = useScoped(TASKS, businessId);
  // Local overrides for done-state + session-added tasks
  const [doneMap, setDoneMap] = useState<Record<string, boolean>>({});
  const [extra, setExtra] = useState<TaskItem[]>([]);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [due, setDue] = useState("");

  const rows = useMemo(
    () =>
      [...extra, ...scoped].map((t) => ({
        ...t,
        done: doneMap[t.id] ?? t.done,
      })),
    [extra, scoped, doneMap]
  );
  const openCount = rows.filter((t) => !t.done).length;
  const doneCount = rows.filter((t) => t.done).length;

  function toggle(id: string, current: boolean) {
    setDoneMap((m) => ({ ...m, [id]: !current }));
  }
  function addTask() {
    if (!title.trim()) return;
    setExtra((p) => [
      {
        id: "T-new-" + Date.now(),
        businessId,
        locationId: "all",
        title,
        due: due || "No due date",
        priority: "Medium",
        assignee: "You",
        done: false,
      },
      ...p,
    ]);
    setTitle("");
    setDue("");
    setOpen(false);
  }

  return (
    <div>
      <PageHeader
        title="Tasks"
        subtitle={`${openCount} open · ${doneCount} completed`}
        action={<Button icon="Plus" onClick={() => setOpen(true)}>New Task</Button>}
      />
      <Card padded={false}>
        <div className="divide-y divide-line-soft">
          {rows.map((t) => (
            <div key={t.id} className="flex items-center gap-3 px-5 py-3.5 hover:bg-surface-sunken">
              <button
                onClick={() => toggle(t.id, t.done)}
                className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors ${
                  t.done ? "border-primary-600 bg-primary-600 text-white" : "border-ink-300 bg-white hover:border-primary-400"
                }`}
                aria-label={t.done ? "Mark as not done" : "Mark as done"}
              >
                {t.done && <Icon name="CheckCircle2" size={14} />}
              </button>
              <div className="min-w-0 flex-1">
                <p className={`text-sm font-medium ${t.done ? "text-ink-400 line-through" : "text-ink-900"}`}>
                  {t.title}
                </p>
                <p className="text-xs text-ink-400">Due {t.due} · {t.assignee}</p>
              </div>
              <StatusBadge status={t.priority} />
            </div>
          ))}
          {rows.length === 0 && <p className="px-5 py-10 text-center text-sm text-ink-400">No tasks for this location.</p>}
        </div>
      </Card>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="New Task"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={addTask} disabled={!title.trim()}>Add</Button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium text-ink-700">Task</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Follow up with customer"
              className="h-10 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-ink-700">Due</label>
            <input
              value={due}
              onChange={(e) => setDue(e.target.value)}
              placeholder="Tomorrow, 3:00 PM"
              className="h-10 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
            />
          </div>
        </div>
      </Modal>
    </div>
  );
}

const channelIcon: Record<string, string> = { SMS: "MessageSquare", Email: "Mail", Call: "PhoneCall" };

export function Communications({ businessId }: { businessId: BusinessId }) {
  const scoped = useScoped(MESSAGES, businessId);
  const [readMap, setReadMap] = useState<Record<string, boolean>>({});
  const rows = scoped.map((m) => ({ ...m, unread: readMap[m.id] ? false : m.unread }));
  const unread = rows.filter((m) => m.unread).length;

  return (
    <div>
      <PageHeader
        title="Communications"
        subtitle={`${unread} unread messages`}
        action={<Button icon="Send">New Message</Button>}
      />
      <Card padded={false}>
        <div className="divide-y divide-line-soft">
          {rows.map((m) => (
            <button
              key={m.id}
              onClick={() => setReadMap((r) => ({ ...r, [m.id]: true }))}
              className="flex w-full items-center gap-3 px-5 py-3.5 text-left hover:bg-surface-sunken"
            >
              <Avatar name={m.from} size={36} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-ink-900">{m.from}</p>
                  <span className="inline-flex items-center gap-1 rounded-full bg-surface px-1.5 py-0.5 text-2xs text-ink-500">
                    <Icon name={channelIcon[m.channel]} size={11} />
                    {m.channel}
                  </span>
                  {m.unread && <span className="h-1.5 w-1.5 rounded-full bg-primary-600" />}
                </div>
                <p className={`truncate text-sm ${m.unread ? "text-ink-700" : "text-ink-400"}`}>{m.preview}</p>
              </div>
              <span className="shrink-0 text-xs text-ink-400">{m.time}</span>
            </button>
          ))}
          {rows.length === 0 && <p className="px-5 py-10 text-center text-sm text-ink-400">No messages for this location.</p>}
        </div>
      </Card>
    </div>
  );
}
