"use client";

import { BusinessId } from "@/lib/types";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { useScoped } from "./scoped";
import { MESSAGES, TASKS } from "@/lib/data";

export function Tasks({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(TASKS, businessId);
  const open = rows.filter((t) => !t.done);
  const done = rows.filter((t) => t.done);

  return (
    <div>
      <PageHeader
        title="Tasks"
        subtitle={`${open.length} open · ${done.length} completed`}
        action={<Button icon="Plus">New Task</Button>}
      />
      <Card padded={false}>
        <div className="divide-y divide-line-soft">
          {rows.map((t) => (
            <div key={t.id} className="flex items-center gap-3 px-5 py-3.5 hover:bg-surface-sunken">
              <span
                className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${
                  t.done ? "border-primary-600 bg-primary-600 text-white" : "border-ink-300 bg-white"
                }`}
              >
                {t.done && <Icon name="CheckCircle2" size={14} />}
              </span>
              <div className="min-w-0 flex-1">
                <p className={`text-sm font-medium ${t.done ? "text-ink-400 line-through" : "text-ink-900"}`}>
                  {t.title}
                </p>
                <p className="text-xs text-ink-400">Due {t.due} · {t.assignee}</p>
              </div>
              <StatusBadge status={t.priority} />
            </div>
          ))}
          {rows.length === 0 && <p className="px-5 py-10 text-center text-sm text-ink-400">No tasks for this location.</p>}
        </div>
      </Card>
    </div>
  );
}

const channelIcon: Record<string, string> = { SMS: "MessageSquare", Email: "Mail", Call: "PhoneCall" };

export function Communications({ businessId }: { businessId: BusinessId }) {
  const rows = useScoped(MESSAGES, businessId);
  return (
    <div>
      <PageHeader
        title="Communications"
        subtitle={`${rows.filter((m) => m.unread).length} unread messages`}
        action={<Button icon="Send">New Message</Button>}
      />
      <Card padded={false}>
        <div className="divide-y divide-line-soft">
          {rows.map((m) => (
            <div key={m.id} className="flex items-center gap-3 px-5 py-3.5 hover:bg-surface-sunken">
              <Avatar name={m.from} size={36} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-ink-900">{m.from}</p>
                  <span className="inline-flex items-center gap-1 rounded-full bg-surface px-1.5 py-0.5 text-2xs text-ink-500">
                    <Icon name={channelIcon[m.channel]} size={11} />
                    {m.channel}
                  </span>
                  {m.unread && <span className="h-1.5 w-1.5 rounded-full bg-primary-600" />}
                </div>
                <p className={`truncate text-sm ${m.unread ? "text-ink-700" : "text-ink-400"}`}>{m.preview}</p>
              </div>
              <span className="shrink-0 text-xs text-ink-400">{m.time}</span>
            </div>
          ))}
          {rows.length === 0 && <p className="px-5 py-10 text-center text-sm text-ink-400">No messages for this location.</p>}
        </div>
      </Card>
    </div>
  );
}
