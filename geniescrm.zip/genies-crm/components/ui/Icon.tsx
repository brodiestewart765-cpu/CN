import {
  LayoutDashboard, UserPlus, Users, Truck, Calendar, Contact, Building2,
  CheckSquare, MessageSquare, FileText, Star, BarChart3, Settings,
  FileSpreadsheet, Sparkles, Route, Home, PieChart, SquareStack,
  Search, Bell, ChevronDown, ChevronRight, ChevronLeft, Plus, Menu, X,
  Filter, MoreHorizontal, MapPin, Phone, Mail, Circle, TrendingUp,
  TrendingDown, DollarSign, Clock, CheckCircle2, Download, Upload,
  ArrowRight, ExternalLink, ArrowUpRight, Wallet, Paperclip, File,
  MessageCircle, PhoneCall, Send, LucideProps, CircleDollarSign,
  ClipboardList, PanelLeftClose, Grip, CreditCard, Link2, RefreshCw,
  Megaphone, Sparkle,
} from "lucide-react";

const MAP: Record<string, React.ComponentType<LucideProps>> = {
  LayoutDashboard, UserPlus, Users, Truck, Calendar, Contact, Building2,
  CheckSquare, MessageSquare, FileText, Star, BarChart3, Settings,
  FileSpreadsheet, Sparkles, Route, Home, PieChart, SquareStack,
  Search, Bell, ChevronDown, ChevronRight, ChevronLeft, Plus, Menu, X,
  Filter, MoreHorizontal, MapPin, Phone, Mail, Circle, TrendingUp,
  TrendingDown, DollarSign, Clock, CheckCircle2, Download, Upload,
  ArrowRight, ExternalLink, ArrowUpRight, Wallet, Paperclip, File,
  MessageCircle, PhoneCall, Send, CircleDollarSign, ClipboardList,
  PanelLeftClose, Grip, CreditCard, Link2, RefreshCw, Megaphone, Sparkle,
};

export function Icon({
  name,
  className,
  size = 18,
  strokeWidth = 2,
}: {
  name: string;
  className?: string;
  size?: number;
  strokeWidth?: number;
}) {
  const Cmp = MAP[name] ?? Circle;
  return <Cmp className={className} size={size} strokeWidth={strokeWidth} />;
}
