"use client";

import { useState } from "react";
import clsx from "clsx";
import { BusinessId } from "@/lib/types";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Avatar } from "@/components/ui/Avatar";
import { BUSINESSES, USERS, locationsFor } from "@/lib/config";

const TABS = [
  { id: "general", label: "General", icon: "Settings" },
  { id: "locations", label: "Locations", icon: "MapPin" },
  { id: "users", label: "Users & Permissions", icon: "Users" },
  { id: "payments", label: "Payments (Stripe)", icon: "CreditCard" },
  { id: "integrations", label: "Integrations", icon: "Grip" },
  { id: "notifications", label: "Notifications", icon: "Bell" },
  { id: "billing", label: "Billing", icon: "Wallet" },
];

const INTEGRATIONS = [
  { name: "Stripe", desc: "Accept card payments & deposits", icon: "CreditCard", tone: "bg-primary-50 text-primary-600", env: "STRIPE_SECRET_KEY" },
  { name: "Google Ads", desc: "Pull spend, leads & ROAS", icon: "Search", tone: "bg-info-50 text-info-600", env: "GOOGLE_ADS_TOKEN" },
  { name: "Meta Ads", desc: "Facebook & Instagram campaigns", icon: "Megaphone", tone: "bg-primary-50 text-primary-600", env: "META_ACCESS_TOKEN" },
  { name: "n8n", desc: "Automations & funnel board", icon: "Sparkle", tone: "bg-warning-50 text-warning-600", env: "N8N_WEBHOOK_URL" },
  { name: "Gmail", desc: "Send & sync email", icon: "Mail", tone: "bg-danger-50 text-danger-500", env: "GMAIL_TOKEN" },
  { name: "Google Business", desc: "Reviews & profile posts", icon: "Star", tone: "bg-warning-50 text-warning-600", env: "GBP_TOKEN" },
];

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-1 gap-1 sm:grid-cols-[180px_1fr] sm:items-center sm:gap-4">
      <label className="text-sm font-medium text-ink-600">{label}</label>
      <input
        defaultValue={value}
        className="h-10 rounded-lg border border-line bg-white px-3 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
      />
    </div>
  );
}

export function Settings({ businessId }: { businessId: BusinessId }) {
  const [tab, setTab] = useState("general");
  const b = BUSINESSES[businessId];
  const [locations, setLocations] = useState(
    locationsFor(businessId).map((l) => ({ ...l }))
  );

  function toggle(id: string) {
    setLocations((ls) => ls.map((l) => (l.id === id ? { ...l, disabled: !l.disabled } : l)));
  }

  return (
    <div>
      <PageHeader title="Settings" subtitle={`${b.name} workspace settings`} />
      <div className="grid gap-5 lg:grid-cols-[220px_1fr]">
        <nav className="card h-fit p-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={clsx(
                "flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left text-sm font-medium transition-colors",
                tab === t.id ? "bg-primary-50 text-primary-700" : "text-ink-600 hover:bg-surface"
              )}
            >
              <Icon name={t.icon} size={16} className={tab === t.id ? "text-primary-600" : "text-ink-400"} />
              {t.label}
            </button>
          ))}
        </nav>

        <div className="card p-6">
          {tab === "general" && (
            <div className="max-w-2xl space-y-5">
              <h3 className="text-md font-semibold text-ink-900">Business Details</h3>
              <Field label="Business Name" value={b.name} />
              <Field label="Business Email" value={`hello@${businessId}scrm.com`} />
              <Field label="Phone" value="(612) 555-0480" />
              <div className="grid grid-cols-1 gap-1 sm:grid-cols-[180px_1fr] sm:gap-4">
                <label className="pt-2 text-sm font-medium text-ink-600">Address</label>
                <textarea
                  defaultValue={"721 Nicollet Ave\nMinneapolis, MN 55402"}
                  rows={2}
                  className="rounded-lg border border-line bg-white px-3 py-2 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
                />
              </div>
              <div className="pt-1">
                <Button>Save Changes</Button>
              </div>
            </div>
          )}

          {tab === "locations" && (
            <div>
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-md font-semibold text-ink-900">Locations</h3>
                  <p className="mt-0.5 text-xs text-ink-500">Add, rename, disable or remove locations for {b.name}.</p>
                </div>
                <Button
                  icon="Plus"
                  onClick={() =>
                    setLocations((ls) => [
                      ...ls,
                      { id: `new-${ls.length + 1}`, businessId, name: `Loco ${ls.length + 1}`, city: "New City" },
                    ])
                  }
                >
                  Add Location
                </Button>
              </div>
              <div className="divide-y divide-line-soft rounded-xl border border-line">
                {locations.map((l) => (
                  <div key={l.id} className="flex items-center gap-3 px-4 py-3">
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-50 text-primary-600">
                      <Icon name="MapPin" size={16} />
                    </span>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-ink-900">{l.name}</p>
                      <p className="text-xs text-ink-400">{l.city}</p>
                    </div>
                    <StatusBadge status={l.disabled ? "Inactive" : "Active"} />
                    <button className="rounded-md p-1.5 text-ink-400 hover:bg-surface hover:text-ink-700" title="Rename">
                      <Icon name="FileText" size={15} />
                    </button>
                    <button onClick={() => toggle(l.id)} className="rounded-md p-1.5 text-ink-400 hover:bg-surface hover:text-ink-700" title="Disable">
                      <Icon name="PanelLeftClose" size={15} />
                    </button>
                    <button
                      onClick={() => setLocations((ls) => ls.filter((x) => x.id !== l.id))}
                      className="rounded-md p-1.5 text-ink-400 hover:bg-danger-50 hover:text-danger-500"
                      title="Delete"
                    >
                      <Icon name="X" size={15} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "users" && (
            <div>
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-md font-semibold text-ink-900">Users &amp; Permissions</h3>
                  <p className="mt-0.5 text-xs text-ink-500">Owners have full access. Add users scoped to a business &amp; location.</p>
                </div>
                <Button icon="Plus">Invite User</Button>
              </div>
              <div className="divide-y divide-line-soft rounded-xl border border-line">
                {USERS.map((u) => (
                  <div key={u.id} className="flex items-center gap-3 px-4 py-3">
                    <Avatar name={u.name} size={36} />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-ink-900">{u.name}</p>
                      <p className="text-xs text-ink-400">{u.email}</p>
                    </div>
                    <StatusBadge status="Active" />
                    <span className="rounded-full bg-primary-50 px-2.5 py-0.5 text-2xs font-medium capitalize text-primary-700">
                      {u.role}
                    </span>
                    <span className="hidden text-xs text-ink-400 sm:block">All businesses · All locations</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "payments" && (
            <div className="max-w-2xl">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
                  <Icon name="CreditCard" size={22} />
                </span>
                <div>
                  <h3 className="text-md font-semibold text-ink-900">Connect Stripe</h3>
                  <p className="text-xs text-ink-500">Accept card payments and deposits from customers.</p>
                </div>
              </div>
              <ol className="mt-4 space-y-2 text-sm text-ink-700">
                <li className="flex gap-2"><span className="font-semibold text-primary-600">1.</span> Create a free account at <span className="font-medium">stripe.com</span> and copy your <span className="font-medium">Secret key</span> (starts with <code className="rounded bg-surface px-1">sk_live_</code>).</li>
                <li className="flex gap-2"><span className="font-semibold text-primary-600">2.</span> In Vercel, open your project → <span className="font-medium">Settings → Environment Variables</span>.</li>
                <li className="flex gap-2"><span className="font-semibold text-primary-600">3.</span> Add <code className="rounded bg-surface px-1">STRIPE_SECRET_KEY</code> with your key, then redeploy.</li>
              </ol>
              <div className="mt-4 rounded-xl border border-line bg-surface-sunken p-4 text-sm">
                <p className="font-medium text-ink-800">That&rsquo;s it — payments go live.</p>
                <p className="mt-1 text-ink-600">The <span className="font-medium">Collect</span> button on any invoice will then open a secure Stripe checkout and charge the card into your account.</p>
              </div>
              <a href="https://dashboard.stripe.com/register" target="_blank" rel="noreferrer">
                <Button className="mt-4" icon="ExternalLink">Create Stripe account</Button>
              </a>
            </div>
          )}

          {tab === "integrations" && (
            <div>
              <h3 className="text-md font-semibold text-ink-900">Integrations</h3>
              <p className="mt-0.5 text-xs text-ink-500">Connect the tools that grow the business. Each activates when its key is added in Vercel.</p>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {INTEGRATIONS.map((it) => (
                  <div key={it.name} className="flex items-center gap-3 rounded-xl border border-line p-3.5">
                    <span className={clsx("flex h-10 w-10 items-center justify-center rounded-xl", it.tone)}>
                      <Icon name={it.icon} size={20} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-ink-900">{it.name}</p>
                      <p className="truncate text-xs text-ink-400">{it.desc}</p>
                    </div>
                    <Button size="sm" variant="secondary">Connect</Button>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-2xs text-ink-400">
                Connections use environment variables (e.g. <code className="rounded bg-surface px-1">STRIPE_SECRET_KEY</code>, <code className="rounded bg-surface px-1">N8N_WEBHOOK_URL</code>) so keys stay private and never touch the browser.
              </p>
            </div>
          )}

          {["notifications", "billing"].includes(tab) && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-surface text-ink-400">
                <Icon name={TABS.find((t) => t.id === tab)!.icon} size={22} />
              </span>
              <p className="mt-3 text-sm font-medium text-ink-800 capitalize">{tab}</p>
              <p className="mt-1 max-w-xs text-xs text-ink-400">
                This section is part of a later phase and will be configured soon.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
