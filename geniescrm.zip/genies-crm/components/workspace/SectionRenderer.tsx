"use client";

import { Suspense } from "react";
import { BusinessId } from "@/lib/types";
import { Dashboard } from "./Dashboard";
import { Leads } from "./Leads";
import { Customers } from "./Customers";
import { Moves, Jobs, Estimates, Routes } from "./MovesJobs";
import { Employees, Vendors } from "./People";
import { Tasks, Communications } from "./TasksComms";
import { Documents, Reviews } from "./DocsReviews";
import { Calendar } from "./Calendar";
import { Reports } from "./Reports";
import { Settings } from "./Settings";
import { MoveDetails } from "./MoveDetails";
import { Payments } from "./Payments";
import { Marketing } from "./Marketing";
import { Icon } from "@/components/ui/Icon";

export function SectionRenderer({
  businessId,
  section,
}: {
  businessId: BusinessId;
  section: string;
}) {
  switch (section) {
    case "dashboard":
      return <Dashboard businessId={businessId} />;
    case "leads":
      return <Leads businessId={businessId} />;
    case "customers":
      return <Customers businessId={businessId} />;
    case "moves":
      return <Moves />;
    case "move-details":
      return (
        <Suspense fallback={null}>
          <MoveDetails />
        </Suspense>
      );
    case "jobs":
      return <Jobs />;
    case "estimates":
      return <Estimates />;
    case "routes":
      return <Routes />;
    case "employees":
      return <Employees businessId={businessId} />;
    case "vendors":
      return <Vendors businessId={businessId} />;
    case "tasks":
      return <Tasks businessId={businessId} />;
    case "communications":
      return <Communications businessId={businessId} />;
    case "documents":
      return <Documents businessId={businessId} />;
    case "reviews":
      return <Reviews businessId={businessId} />;
    case "calendar":
      return <Calendar businessId={businessId} />;
    case "payments":
      return <Payments businessId={businessId} />;
    case "marketing":
      return <Marketing businessId={businessId} />;
    case "reports":
      return <Reports businessId={businessId} />;
    case "settings":
      return <Settings businessId={businessId} />;
    default:
      return (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-surface text-ink-400">
            <Icon name="Search" size={22} />
          </span>
          <p className="mt-3 text-sm font-medium text-ink-800">Section not found</p>
          <p className="mt-1 text-xs text-ink-400">This page doesn&rsquo;t exist in this workspace.</p>
        </div>
      );
  }
}
