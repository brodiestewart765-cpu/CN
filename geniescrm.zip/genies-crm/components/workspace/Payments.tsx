"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { BusinessId, Invoice } from "@/lib/types";
import { PageHeader } from "@/components/ui/PageHeader";
import { KpiCard } from "@/components/ui/KpiCard";
import { DataTable, Column } from "@/components/ui/DataTable";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { Modal } from "@/components/ui/Modal";
import { useScoped } from "./scoped";
import { INVOICES } from "@/lib/data";
import { money } from "@/lib/format";
import { useApp } from "@/lib/app-context";
import { locationsFor } from "@/lib/config";

export function Payments({ businessId }: { businessId: BusinessId }) {
  const scoped = useScoped(INVOICES, businessId);
  const { locationByBusiness } = useApp();
  const loc = locationByBusiness[businessId];
  const defaultLoc = loc !== "all" ? loc : locationsFor(businessId)[0]?.id ?? "";

  const [extra, setExtra] = useState<Invoice[]>([]);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});

  const rows = useMemo(() => [...extra, ...scoped], [extra, scoped]);

  const collected = rows.filter((i) => i.status === "Paid").reduce((a, i) => a + i.amount, 0);
  const outstanding = rows.filter((i) => i.status === "Unpaid" || i.status === "Overdue").reduce((a, i) => a + i.amount, 0);
  const overdue = rows.filter((i) => i.status === "Overdue").length;

  async function collect(inv: Invoice) {
    setBusyId(inv.id);
    setNotice(null);
    try {
      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: inv.amount,
          description: inv.description,
          customer: inv.customer,
          invoiceId: inv.id,
        }),
      });
      const data = await res.json();
      if (data.url) {
        window.open(data.url, "_blank");
      } else if (data.configured === false) {
        setNotice(data.error || "Connect Stripe in Settings to accept card payments.");
      } else {
        setNotice(data.error || "Could not start checkout.");
      }
    } catch {
      setNotice("Network error creating the payment link.");
    } finally {
      setBusyId(null);
    }
  }

  function addInvoice() {
    const amount = Number(form.amount);
    if (!form.customer?.trim() || !amount) return;
    setExtra((p) => [
      {
        id: "INV-" + Date.now().toString().slice(-5),
        businessId,
        locationId: defaultLoc,
        customer: form.customer,
        description: form.description || "Service",
        amount,
        status: "Unpaid",
        date: "just now",
      },
      ...p,
    ]);
    setForm({});
    setOpen(false);
  }

  const columns: Column<Invoice>[] = [
    { key: "id", header: "Invoice", render: (r) => <span className="font-medium text-primary-700">{r.id}</span> },
    { key: "customer", header: "Customer", render: (r) => <span className="font-medium text-ink-800">{r.customer}</span> },
    { key: "description", header: "Description", render: (r) => <span className="text-ink-600">{r.description}</span> },
    { key: "amount", header: "Amount", align: "right", render: (r) => <span className="font-semibold text-ink-900">{money(r.amount)}</span> },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
    {
      key: "action",
      header: "",
      align: "right",
      render: (r) =>
        r.status === "Paid" ? (
          <span className="inline-flex items-center gap-1 text-xs text-success-600"><Icon name="CheckCircle2" size={14} /> Paid</span>
        ) : (
          <Button
            size="sm"
            variant="secondary"
            icon="CreditCard"
            onClick={() => collect(r)}
            disabled={busyId === r.id}
          >
            {busyId === r.id ? "Opening…" : "Collect"}
          </Button>
        ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Payments"
        subtitle="Invoices and card payments powered by Stripe"
        action={<Button icon="Plus" onClick={() => setOpen(true)}>New Invoice</Button>}
      />

      <div className="mb-5 grid gap-4 sm:grid-cols-3">
        <KpiCard label="Collected" value={money(collected)} icon="CircleDollarSign" iconTone="green" sublabel="paid to date" />
        <KpiCard label="Outstanding" value={money(outstanding)} icon="Clock" iconTone="amber" sublabel={`${rows.filter((i)=>i.status!=="Paid").length} open`} />
        <KpiCard label="Overdue" value={`${overdue}`} icon="CreditCard" iconTone="rose" sublabel="need attention" />
      </div>

      {notice && (
        <div className="mb-4 flex items-start gap-3 rounded-xl border border-warning-100 bg-warning-50 px-4 py-3">
          <Icon name="CreditCard" size={18} className="mt-0.5 text-warning-600" />
          <div className="flex-1 text-sm text-warning-700">
            {notice}{" "}
            <Link href={`/w/${businessId}/settings`} className="font-semibold underline">
              Open Settings → Payments
            </Link>
          </div>
          <button onClick={() => setNotice(null)} className="text-warning-600 hover:text-warning-700"><Icon name="X" size={16} /></button>
        </div>
      )}

      <DataTable
        columns={columns}
        rows={rows}
        getKey={(r) => r.id}
        rowAction={false}
        toolbar={
          <div className="flex items-center gap-2 text-sm text-ink-500">
            <Icon name="CreditCard" size={16} className="text-primary-600" />
            <span>Click <span className="font-medium text-ink-700">Collect</span> to send a secure Stripe payment link.</span>
          </div>
        }
      />

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="New Invoice"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={addInvoice} disabled={!form.customer?.trim() || !Number(form.amount)}>Create</Button>
          </>
        }
      >
        <div className="space-y-4">
          {[
            { key: "customer", label: "Customer", ph: "Jane Doe" },
            { key: "description", label: "Description", ph: "Move deposit" },
            { key: "amount", label: "Amount ($)", ph: "350" },
          ].map((f) => (
            <div key={f.key}>
              <label className="mb-1 block text-sm font-medium text-ink-700">{f.label}</label>
              <input
                value={form[f.key] ?? ""}
                placeholder={f.ph}
                onChange={(e) => setForm((p) => ({ ...p, [f.key]: e.target.value }))}
                className="h-10 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
              />
            </div>
          ))}
          <p className="text-xs text-ink-400">Once Stripe is connected, click Collect on any invoice to charge the card.</p>
        </div>
      </Modal>
    </div>
  );
}
