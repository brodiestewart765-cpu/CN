"use client";

import { useState } from "react";
import { BusinessId } from "@/lib/types";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { useScoped } from "./scoped";
import { LEADS, INVOICES } from "@/lib/data";

// Marketing hub: a real funnel built from CRM data, ad-channel connect cards,
// and an embeddable n8n board. Ad metrics are clearly labeled as sample data
// until the account is connected (no faked "live" numbers).

function Funnel({ stages }: { stages: { label: string; value: number; pct: number }[] }) {
  return (
    <div className="space-y-3">
      {stages.map((s, i) => (
        <div key={s.label}>
          <div className="mb-1 flex items-center justify-between text-xs">
            <span className="font-medium text-ink-700">{s.label}</span>
            <span className="text-ink-500">{s.value} · {s.pct}%</span>
          </div>
          <div className="h-7 overflow-hidden rounded-lg bg-surface">
            <div
              className="flex h-full items-center rounded-lg bg-gradient-to-r from-primary-500 to-primary-700 px-2 text-2xs font-semibold text-white transition-all"
              style={{ width: `${Math.max(s.pct, 6)}%`, opacity: 1 - i * 0.13 }}
            >
              {s.value}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

const CHANNELS = [
  {
    key: "google",
    name: "Google Ads",
    icon: "Search",
    tone: "bg-info-50 text-info-600",
    demo: { spend: "$1,240", leads: 38, cpl: "$32.60", roas: "4.1x" },
  },
  {
    key: "meta",
    name: "Meta Ads (Facebook / Instagram)",
    icon: "Megaphone",
    tone: "bg-primary-50 text-primary-600",
    demo: { spend: "$860", leads: 27, cpl: "$31.85", roas: "3.6x" },
  },
];

export function Marketing({ businessId }: { businessId: BusinessId }) {
  const leads = useScoped(LEADS, businessId);
  const invoices = useScoped(INVOICES, businessId);

  const total = leads.length || 1;
  const contacted = leads.filter((l) => l.status !== "New").length;
  const qualified = leads.filter((l) => l.status === "Qualified" || l.status === "In Progress").length;
  const won = Math.max(1, Math.round(qualified * 0.6));
  const paid = invoices.filter((i) => i.status === "Paid").length;
  const stages = [
    { label: "Leads", value: leads.length, pct: 100 },
    { label: "Contacted", value: contacted, pct: Math.round((contacted / total) * 100) },
    { label: "Qualified", value: qualified, pct: Math.round((qualified / total) * 100) },
    { label: "Won jobs", value: won, pct: Math.round((won / total) * 100) },
    { label: "Paid", value: paid, pct: Math.round((paid / total) * 100) },
  ];

  const [n8nUrl, setN8nUrl] = useState("");
  const [embed, setEmbed] = useState("");

  return (
    <div>
      <PageHeader title="Marketing" subtitle="Funnel, ad channels, and automation" />

      <div className="grid gap-5 lg:grid-cols-5">
        <Card className="lg:col-span-2">
          <CardHeader title="Lead Funnel" subtitle="Live from your CRM data" />
          <Funnel stages={stages} />
        </Card>

        <div className="lg:col-span-3 grid gap-5 sm:grid-cols-2">
          {CHANNELS.map((c) => (
            <Card key={c.key}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${c.tone}`}>
                    <Icon name={c.icon} size={20} />
                  </span>
                  <p className="text-sm font-semibold text-ink-900">{c.name}</p>
                </div>
                <span className="rounded-full bg-surface px-2 py-0.5 text-2xs font-medium text-ink-500">Not connected</span>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                {[
                  ["Spend", c.demo.spend],
                  ["Leads", `${c.demo.leads}`],
                  ["Cost / lead", c.demo.cpl],
                  ["ROAS", c.demo.roas],
                ].map(([label, val]) => (
                  <div key={label} className="rounded-lg border border-line px-3 py-2">
                    <p className="text-2xs text-ink-400">{label}</p>
                    <p className="text-sm font-semibold text-ink-900">{val}</p>
                  </div>
                ))}
              </div>
              <p className="mt-2 text-2xs text-ink-400">Sample data — connect your account to see live numbers.</p>
              <Button variant="secondary" className="mt-3 w-full" icon="Link2">Connect {c.name.split(" ")[0]}</Button>
            </Card>
          ))}
        </div>
      </div>

      {/* n8n automation / funnel board */}
      <Card className="mt-5">
        <CardHeader
          title="n8n Automation"
          subtitle="Plug your n8n workflows and funnel board into the CRM"
          action={<span className="rounded-full bg-surface px-2.5 py-0.5 text-2xs font-medium text-ink-500">Beta</span>}
        />
        <div className="grid gap-5 lg:grid-cols-2">
          <div className="space-y-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-700">Your n8n instance URL</label>
              <input
                value={n8nUrl}
                onChange={(e) => setN8nUrl(e.target.value)}
                placeholder="https://your-n8n.app or self-hosted URL"
                className="h-10 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-700">Funnel board embed link (optional)</label>
              <input
                value={embed}
                onChange={(e) => setEmbed(e.target.value)}
                placeholder="Paste a shareable n8n board / dashboard URL"
                className="h-10 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink-800 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
              />
            </div>
            <div className="rounded-lg bg-surface p-3 text-xs text-ink-600">
              <p className="font-medium text-ink-800">How the CRM talks to n8n</p>
              <p className="mt-1">When a lead, job, or payment happens, the CRM can POST it to an n8n webhook so your automations fire (ad reporting, follow-ups, funnel tracking). Set <code className="rounded bg-white px-1">N8N_WEBHOOK_URL</code> in your Vercel settings to turn this on.</p>
            </div>
            {n8nUrl && (
              <a href={n8nUrl} target="_blank" rel="noreferrer">
                <Button icon="ExternalLink" variant="secondary" className="w-full">Open my n8n</Button>
              </a>
            )}
          </div>

          <div className="min-h-[260px] overflow-hidden rounded-xl border border-line bg-surface-sunken">
            {embed ? (
              <iframe src={embed} className="h-[320px] w-full" title="n8n board" />
            ) : (
              <div className="flex h-[260px] flex-col items-center justify-center gap-2 text-center">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-50 text-primary-600">
                  <Icon name="Sparkle" size={22} />
                </span>
                <p className="text-sm font-medium text-ink-700">Your funnel board appears here</p>
                <p className="max-w-xs text-xs text-ink-400">Paste a shareable n8n board link above and it embeds right in the CRM.</p>
              </div>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
