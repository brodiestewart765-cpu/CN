import Link from "next/link";
import { Icon } from "@/components/ui/Icon";

export default function PaymentSuccess() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-surface px-6 text-center">
      <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-success-50 text-success-600">
        <Icon name="CheckCircle2" size={32} />
      </span>
      <div>
        <p className="text-2xl font-semibold text-ink-900">Payment received</p>
        <p className="mt-1 text-sm text-ink-500">Thanks! Your payment was processed securely by Stripe.</p>
      </div>
      <Link href="/" className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-primary-600 px-4 text-sm font-medium text-white hover:bg-primary-700">
        <Icon name="Home" size={16} /> Back to Genie&rsquo;s CRM
      </Link>
    </div>
  );
}
