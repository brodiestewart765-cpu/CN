import { NextRequest, NextResponse } from "next/server";

// Real Stripe Checkout session creator.
// Activates automatically once STRIPE_SECRET_KEY is set in the Vercel project's
// Environment Variables. Until then it returns a clear "not configured" message
// so the UI can prompt the owner to connect Stripe (graceful degradation).
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    return NextResponse.json(
      {
        configured: false,
        error:
          "Stripe is not connected yet. Add STRIPE_SECRET_KEY in your Vercel project settings to enable live payments.",
      },
      { status: 200 }
    );
  }

  let body: { amount?: number; description?: string; customer?: string; invoiceId?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const amount = Math.round(Number(body.amount) * 100);
  if (!amount || amount < 50) {
    return NextResponse.json({ error: "Amount must be at least $0.50." }, { status: 400 });
  }

  try {
    // Lazy import so a missing dependency/key never breaks the build.
    const Stripe = (await import("stripe")).default;
    const stripe = new Stripe(key);

    const origin =
      req.headers.get("origin") ??
      `https://${req.headers.get("host") ?? "localhost:3000"}`;

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          quantity: 1,
          price_data: {
            currency: "usd",
            unit_amount: amount,
            product_data: {
              name: body.description || "Genie's CRM Invoice",
            },
          },
        },
      ],
      metadata: {
        invoiceId: body.invoiceId ?? "",
        customer: body.customer ?? "",
      },
      success_url: `${origin}/payment-success`,
      cancel_url: `${origin}/payment-cancelled`,
    });

    return NextResponse.json({ configured: true, url: session.url });
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message ?? "Stripe error creating checkout session." },
      { status: 500 }
    );
  }
}
